# DeepText-Classification: An Open-source Neural Text Classification Toolkit #

***Author: Marvinmu, Liqunliu, Felixai, Ranfu, Jamesjtang, Perrypyli, Fandywang***

![DeepText](img/deeptext_logo.png "DeepText")

DeepText is a Tensorflow/PyTorch-based deep learning NLP public experiment platform built by targeting team of Tencent Social Advertising (TSA). It mainly covers text classification, tagging, matching, generation, etc. DeepText is currently widely used in text-related category mining scenarios of social advertising, serving business applications such as ad targeting, relevance calculation, lookalike, dynamic creative, and pCTR/pCVR.

This project(DeepText-Classification) is part of the DeepText, to our knowledge, DeepText-Classification is known in the industry's most comprehensive deep learning text classification toolkit.

----------

[TOC]

# 1. DeepText-Classification Introduction #
## 1.1 Foreword ##
Text classification(categorization) is one of the classic tasks of NLP and using deep learning is state-of-the-art method. On the one hand, new models and methods for deep learning of text classification continue to emerge. On the other hand, deep learning and development platforms are diverse, such as TensorFlow, PyTorch, Caffe, etc, and these development platforms are constantly upgrading APIs to add support for new functions or features. Currently, some open source tools for text classification in the industry are relatively fragmented, or have poor code style, or inefficient code execution, or use APIs that are older, or model coverage is incomplete, or mechanisms (such as Attention, Pre-trained embedding, etc.) are insufficiently supported, etc. There is no full-featured and easily available open source tool for neural text classification.

Based on the above reasons, we have developed a neural text classification toolkit named DeepText-Classification. It integrates neural text classification models and mechanisms into a unified framework, using TensorFlow's latest High-level API for development, and allow for more flexible integration of more models or methods.

* Support more models: mainstream models such as FastText, TextCNN, TextRNN (Bi-GRU/LSTM), etc., also support the latest state-of-the-art models such as VDCNN, DPCNN, Region Embedding, AttentiveConvNet, DRNN, etc., and facilitate user support custom model structure.
* Support mainstream mechanisms such as Attention, Pre-trained embedding, etc.
* Support multi-threaded accelerated reading of data input, variable-length and fixed-length input, word and character-level input, custom input, and more.
* Support multiple optimization methods, such as Adagrad, Adam, FTRL, Momentum, RMSProp, SGD, etc.
* Support multiple loss functions such as Softmax, NCE Loss, Focal Loss etc.
* Support multiple classification tasks, such as binary classification, multi-classification, multi-label classification and hierarchical classification.
* Support ensemble multiple models for evaluation and prediction.

In order to verify the effectiveness of the DeepText-Classification implementation, we compared 15 text classification datasets published in the industry. The data size range from a few thousand to several million. The classification tasks included binary classification and multi classification, and DeepText-Classification model-reconstructed them. The results show that DeepText-Classification is competitive and has better results than papers in several datasets.

## 1.2 Technology Architecture ##
### 1.2.1 DeepText-Classification System Framework ###
DeepText-Classification framework can be abstracted into four layers: the input layer, the embedding layer, the model layer, and the classifier layer, as shown in the following figure.
![DeepText-Classification framework](img/sys_arc.png "DeepText-Classification framework")	
### 1.2.2 DeepText-Classification Process Flow ###
DeepText-Classification is implemented using TensorFlow High-level API, and the cores are DataSet, TFRecord, Estimator. DataSet and TFRecord enable us to process input data in a structured and efficient manner. Estimator allows us to efficiently develop models and provide flexible extensions, as shown in the following figure.
![DeepText-Classification flow](img/deeptext_flow.png "DeepText-Classification flow")

# 2. Required environment #
- TensorFlow 1.6+
- Python 3.6+
- Numpy 1.13.3+
- CUDA 9.0.176 (Depends on TensorFlow version)
- CUDNN 7.0.5 (Depends on TensorFlow version)

# 3. Quick Start
Take the textcnn model entered by char as an example to quickly see how DeepText-Classification is trained, evaluated, predicted, and tuned.

Training：
	
	python train.py conf/textcnn_char.config
Run the above command, DeepText-Classification will load the input data, process the data in the configuration file, train and evaluate.

- model dir: export\_model
- checkpoint dir: checkpoint
- tfrecord dir: tfrecord
- dict dir: dict
- Log：log
- evaluation output dir: eval\_dir

export\_model save the training model in each epoch.

In the log file, you can grep out every epoch of "validate performance" and the last "test performance".

You can see the test performance in eval_dir, using the model that has the best performance in validate data.

Training details: Refer to section 5.1.

If you want to tune this model, you can modify textcnn\_char.config to retrain. For details, see section 8.

General tuning ideas:

- The model does not converge: Adjust the learning rate (usually adjusted from 0.1), increase the batch_size, increase the complexity of the model, etc.
- Model overfitting: Reduce the embedding dimension, use drop out, reduce model complexity, increase regular loss, etc.
- Slower model convergence: Reduce learning rate, reduce model complexity, etc.
- fine-tune the model: grid-search search parameters

# 4. Data Input #
  Data format(4 columns):

    label\t[(token )+]\t[(char )+]\t[(custom_feature )+]
    label: class label, can be hierarchical: cate1--cate2--cate3
    token: Chinese/English words, No need to convert to ids
    char: Chinese/English characters, No need to convert to ids
    custom_feature: custom feature, currently supports discrete features
    Note: label is required, token, char, custom_feature at least one, others need leave empty
DeepText-Classification converts data to TFRecord before training. TFRecord is usually generated once and can be used by multiple models. Unless you change the configuration related to data processing, such writing can also facilitate the ensembele of subsequent models.

By default, the data file is UTF-8 encoded. For the modification, refer to util.CHARSET.

DeepText-Classification provides the TREC classification dataset, which is publicly available in the industry. It allows users t quickly run DeepText-Classification and observe the impact of hyperparameter settings on performance.

TREC is a question dataset with 6 categories, which are HUM, LOC, DESC, NUM, ENTY, and ABBR. The dataset size is 5952, with an average length of 10.

# 5. Training and Evaluation #
## 5.1 Training ##
	python train.py conf/textcnn_char.config

Here is an example of textcnn input by char, all supported models refer to section 5.4, and all configs refer to section 8.

In each epoch, the training and evalutaion information is recorded in the log:
validate performance represents the performance of validation set, if use config "eval\_train\_data", performance of training set will be recorded.
![train_log](img/train_log.png "train_log")

After the iteration is completed(num\_epochs), DeepText-Classification will eval test dataset and output performance of test set. DeepText-Classification records the best validate performance model during training and calculates the corresponding test performance.
![validate_log](img/validate_log.png "validate_log")

Note: 

- By default, the model is loaded from checkpoint. If you train a model from scratch, make sure that the checkpoint, tfrecord, and export_model directories are empty.
- textcnn\_char.config includes all configurations about textcnn, including training, evaluation, and prediction.

## 5.2 Using pre-trained embedding ##
### 5.2.1 Preparing pre-trained embedidng file ###
Using pre-trained embedding requires an extra embedding file(for example, embedding trained with word2vec), The format is as follows:

    word embedding_dim1 embedding_dim2 ...

DeepText-Classification supports three inputs, which are token, char and custom\_feature, Therefore, it provides three pre-trained embedding files. The corresponding configs are:

- token\_pretrained\_embedding\_file
- char\_pretrained\_embedding\_file
- custom\_feature\_pretrained\_embedding\_file

### 5.2.2 Choose the way of pre-trained embedding training ###
Pre-trained embedding in the classification model training is generally divided into two categories: static, non-static. We use the num\_epochs\_static\_embedding config to control how to use pre-trained embedding. This config indicates that the pre-trained embedding was static during the first few epochs. For example, a value of 0 means non-static. In the first epoch, it starts to be trained along with other parameters. Take 2 means that in the first 2 epochs, pre-trained embedding is not updated, only the upper parameters are updated. In the third eooch, pre-trained embedding is trained with other parameters.If taking more than the maximum number of iterations of the value, you can achieve the static function.

## 5.3 Evaluation ##
Although the validation set and test set are evaluated during train.py training, sometimes we want to use a specified model to evaluate a file. The script is as follows:

     python evaluate.py conf/textcnn_char.config

The main concern configuration:

    "eval": {                                                                   
        "text_file": "data/trec_validate.txt",
        "threshold": 0.0,
        "eval_dir": "eval_dir",  
        "is_flat": true
    }
    "predict": {
        "model_tag": "serve",
        "model_dirs": ["export_model/1527501251", "export_model/1527501256"],
        "model_weights": [0.6, 0.4] 
    }

- text\_file: evaluate file

- is\_flat: Whether the label is hierarchical or not. When it is false, the evaluation of the hierarchical classification is performed. The labels are separated by "--" to calculate the indexes of multiple levels.

- model\_dirs: Multiple models can be provided, using probabilistic additive ensemble methods. Note the tfrecord of those models should be consistent.

- model\_weights: Linear weighted weights of models in model\_dirs.

## 5.4 Supported Models Overview ##
DeepText-Classification currently supports models are as follows:

<table>
<tr align="middle"><th><th>char<th>token<th>自定义输入<th>pre-trained embedding<th>定长输入<th>变长输入<th>ngram<th>attention
<tr align="middle"><td>FastText <td>yes<td>yes<td>yes<td>yes<td>yes<td>yes<td>yes<td>no
<tr align="middle"><td>TextCNN <td>yes<td>yes<td>no<td>yes<td>yes<td>no<td>no<td>no
<tr align="middle"><td>TextRNN <td>yes<td>yes<td>no<td>yes<td>yes<td>no<td>no<td>yes
<tr align="middle"><td>VDCNN <td>yes<td>yes<td>no<td>yes<td>yes<td>no<td>no<td>no
<tr align="middle"><td>DPCNN <td>yes<td>yes<td>no<td>yes<td>yes<td>no<td>no<td>no
<tr align="middle"><td>Region Embedding <td>yes<td>yes<td>no<td>yes<td>yes<td>no<td>no<td>no
<tr align="middle"><td>AttentiveConvNet <td>yes<td>yes<td>no<td>yes<td>yes<td>no<td>no<td>yes
<tr align="middle"><td>DRNN <td>yes<td>yes<td>no<td>yes<td>yes<td>no<td>no<td>no
</table>
The features that are not supported above can be customized by the users. See Section 7 for details.

The configurations used by each model are not the same. We provide a recommended configuration for each model (including mechanisms) (more configuration user-definable), which can greatly simplify the use of tools.

	fasttext_token_char.config
	fasttext_token_char_custom_feature.config
	fasttext_token_char_tokenbigram_chartrigram.config
	textcnn_char.config
	textcnn_token.config
	bilstm_token.config
	bilstm_token_attention.config
	bilstm_char.config
	bilstm_char_attention.config
	bigru_token.config
	bigru_token_attention.config
	bigru_char.config
	bigru_char_attention.config
	vdcnn_char.config
	dpcnn_token.config
	dpcnn_char.config
	region_embedding_wc_token.config
	region_embedding_cw_token.config
	attentiveconvnet_light_token.config
	attentiveconvnet_advanced_token.config
	drnn_token.config

# 6. Prediction #
## 6.1 Offline prediction ##
Same as 5.3 evaluation module evaluate.py, the code encapsulates the call prediction module predict.py, the prediction module supports single-model prediction and multi-model ensemble prediction (By default, the predicted probability is added).

## 6.2 Online prediction(Model deployment) ##
The offline training model is deployed online and an inference RPC service needs to be built. There are two general ways of providing services. One is to encapsulate predict.py in python, and the other is to use TF Serving. This part currently requires the user to develop it himself (DeepText-Classification will open the service code later).

# 7. Custom development #
DeepText-Classification's good architecture design allows developers to customize development.
## 7.1 Add a model ##
DeepText-Classification allows developers to flexibly add custom models that need to be changed:

- Add a model definition file, refer to the model file (such as text_cnn.py) in the model directory and inherit the Estimator
- train.py add import
- config.json add related config(if necessary)

## 7.2 Modify model network structure ##
Modify the model file in the model directory.

## 7.3 Modify embedding ##
Refer to the model/embedding_layer file.

## 7.4 Modify data input ##
Refer to data\_processor.py.

# 8. Config Introduction #
All the hyper-parameters used by DeepText-Classification are specified by config file of json format, referencing config.json.
Those configs are divided into 12 modules according to their functions, which are:

- Data
- Feature
- Fixed len input
- Var len input
- Training
- Optimizer
- Embedding
- Model common
- Log
- Model-specific
- Evaluation
- Prediction

The following are all configs (config.json) and comments:

**Data Configs:**

	MODULE_NAME = "data"
	# Traing set
	"train_text_file": "data/trec_train.txt",
	"comment": "Input train text file."
	           "Shuffle your train data at first"
	           "Text format: label\t[(token )+]\t[(char )+]\t"
	           "[(custom_feature )+]. Label could be flattened or "
	           "hierarchical which is separated by '--'."
	
	# Validation Set
	"validate_text_file": "data/trec_validate.txt",
	"comment": "Input validate text file."
	           "Text format: label\t[(token )+]\t[(char )+]\t"
	           "[(custom_feature )+]. Label could be flattened or "
	           "hierarchical which is separated by '--'."

	# Test Set
	"test_text_file": "data/trec_test.txt",
	"comment": "Input test text file."
	           "Text format: label\t[(token )+]\t[(char )+]\t"
	           "[(custom_feature )+]. Label could be flattened or "
	           "hierarchical which is separated by '--'."
	
	# tfrecord dir
	"tfrecord_dir": "tfrecord"
	"comment": "Directory to save tfrecord."
	
	# Dict dir
	"dict_dir": "dict"
	"comment": "Directory to save dicts and "
	           "configs of module data_processor."
	
	# Shuffle buffer size, it is best to set no less than the number of training set samples
	"shuffle_buffer": 1000000
	"comment": "Shuffle buffer used by tf.dataset, the bigger the "
	           "better. Shuffle your train data at first"

**Feature Configs:**
	
	MODULE_NAME = "feature_common"
	# The type of input sequence used, which can be token, char, and custom_feature
	"feature_names": "token"
	"comment": "Feature names to use, separated by comma."
	           "candidate is in DataProcessor.dict_names"
	
	# The minimum number of token truncations
	"min_token_count": 2
	"comment": "Min count of token."
	
	# The minimum number of char truncations
	"min_char_count": 2
	"comment": "Min count of char."
	
	# The minimum number of char in token
	"min_char_count_in_token":0
	"comment": "Min char count in token"
		
	# The maximum number of truncations in the token dictionary
	"max_token_dict_size": 1000000
	"comment": "Max dict size of token."
	
	# The maximum number of truncations in the char dictionary
	"max_char_dict_size": 150000,
	"comment": "Max dict size of char."
	
	# The maximum dict size of char in tokens 
	"max_char_in_token_dict_size": 1000000
	"comment": "max dict size of char in tokens"
	
	# Pre-trained embedding file of token
	"token_pretrained_embedding_file": ""
	"comment": "Pretrained token embedding file"
	
	# Pre-trained embedding file of char
	"char_pretrained_embedding_file":""
	"comment": "Pretrained char embedding file"

**Fixed len input Configs:**

	MODULE_NAME = "fixed_len_feature"
	# The maximum number of tokens
	"max_token_sequence_length": 256
	"comment": "Max length of token per example."
	
	# Padding size at the begin of the token list.
	# this feature may improve performance in some convolutional networks, or region embedding networks.
	"token_padding_begin": 0
	"comment": "Padding size at the begin of the token list."
	
	# Padding size at the end of the token list.
	# this feature may improve performance in some convolutional networks, or region embedding networks.
	"token_padding_end": 0
	"comment": "Padding size at the end of the token list."	
	
	# Max char length per token
	"max_char_length_per_token": 4
	"comment": "Max char length per token"
	
	# he number of paddings at the begin of the char in each token
	"char_padding_per_token_begin": 0
	"comment": "The number of paddings at the begin of the char in each token"
	
	# The number of paddings at the end of the char in each token
	"char_padding_per_token_end": 0
	"comment": "The number of paddings at the end of the char in each token"
	
	# The maximum number of chars
	"max_char_sequence_length": 512
	"comment": "Max length of char per example."
		
	# Padding size at the begin of the char list.
	# this feature may improve performance in some convolutional networks, or region embedding networks.
	"char_padding_begin": 0
	"comment": "Padding size at the begin of the char list."
	
	# Padding size at the end of the char list
	# this feature may improve performance in some convolutional networks, or region embedding networks.
	"char_padding_end": 0
	"comment": "Padding size at the end of the char list."

**Val len input Configs:**

	MODULE_NAME = "var_len_feature"
	# The maximum number of tokens (Variable length input)
	"max_var_token_length": -1
	"comment": "Max length of var token per example."
	           "-1 mean unlimited."
	
	# The maximum number of chars (Variable length input)
	"max_var_char_length": -1
	"comment": "Max length of var char per example."
	           "-1 mean unlimited."
	
	# Token ngram, for example, the value is 2, which means bigram that automatically calculated
	"token_ngram": 1
	"comment": "Ngram of token."
	
	# Char ngram, for example, the value is 2, which means bigram that automatically calculated
	"char_ngram": 1
	"comment": "Ngram of char."
	
	# The minimum number of token ngram truncations
	"min_token_ngram_count": 2
	"comment": "Min token ngram count."
	
	# The minimum number of char ngram truncations
	"min_char_ngram_count": 2
	"comment": "Min char ngram count."
	
	# Max size of token ngram
	"max_token_ngram_dict_size": 1000000
	"comment": "Max dict size of token ngram."
	
	# Max size of char ngram
	"max_char_ngram_dict_size": 2000000
	"comment": "Max dict size of char ngram."
	
	# The maximum number of custom_feature(Variable length input)
	"max_var_custom_feature_length": -1
	"comment": "Max length of var custom feature per example."
	           "-1 mean unlimited."
	
	# The minimum number of custom_feature truncations
	"min_custom_feature_count": 2
	"comment": "Min count of custom feature."
	
	# Max dict size of custom_feature
	"max_custom_feature_dict_size": 10000
	"comment": "Max dict size of custom feature."
	
	# Pre-trained embedding file of custom_feature
	"custom_feature_pretrained_embedding_file": ""
	"comment": "Pretrained custom feature embedding file"

**Training Configs:**

	MODULE_NAME = "train"
	# batch size
	"batch_size": 128
	"comment": "Training mini batch size."
	
	# When evaluating the training set, the batch size at this time
	"predict_batch_size": 4096
	"comment": "Predicting mini batch size. The bigger, the faster."
	            "But limited by memory size. "
	            "For TextCNN this value should be set smaller"
	
	# Where training set evaluated during training or not
	"eval_train_data": false
	"comment": "Whether to eval train data at every epoch"
	
	# Learning rate
	"learning_rate": 0.001
	"comment": "Learning rate for training."
	
	# Max epochs
	"num_epochs": 4
	"comment": "Number of training epochs."
	
	# Use static embedding epochs
	"num_epochs_static_embedding": 0
	"comment": "Number of training epochs that embedding will not be "
	           "updated. If bigger than num_epochs, then embedding "
	           "will remain as it is first initialized. Usually used "
	           "when embedding is initialized with pretrained "
	           "embedding"
	
	# Decay steps
	"decay_steps": 1000
	"comment": "How many steps before decay learning rate."
	
	# Decay rate
	"decay_rate": 0.65
	"comment": "Rate of decay for learning rate."
	
	# Clip gradients
	"clip_gradients": 5.0
	"comment": "Clip absolute value gradient bigger than threshold."
	
	# l2 norm lambda
	"l2_lambda": 0.0001
	"comment": "lambda value of l2 norm."
	
	# loss function
	"loss_type": "Softmax"
	"comment": "Loss type. Candidate: Softmax, NCE, SoftmaxFocalLoss"
	
	# sampler, only used when loss function is NCE
	"sampler": "fixed"
	"comment": "If loss type is NCE, sampler is needed. Candidate: "
	           "fixed, log, learned, uniform."
	           "More details in tensorflow api doc: "
	           "https://www.tensorflow.org/api_guides/"
	           "python/nn#Candidate_Sampling"
	
	# The number of samples used only when the loss function is NCE
	"num_sampled": 5
	"comment": "If loss type is NCE, need to sample negative labels."
	
	# Hidden layer dropout
	"hidden_layer_dropout_keep_prob": 0.5
	"comment": "Dropout prob of hidden layer."
	
	# Which gpu to use, such as '0,1', then use the 0th and 1st GPU cards
	"visible_device_list": "0"
	"comment": "Which gpu to use, separated by comma."
	
	# Timeline
	"track_timeline": false
	"comment": "Whether to track the timeline."

**Optimizer Configs:**

	MODULE_NAME = "optimizer"
	# Optimizer type
	"optimizer": "Adam"
	"comment": "Optimizer of loss. Candidate: "
	           "Adagrad, Adam, Ftrl, Momentum, RMSProp, SGD, Adadelta."
	
	# Decay rate of adadelta
	"adadelta_decay_rate": 0.95
	"comment": "Decay rate of adadelta, useful when optimizer is "
	           "Adadelta"
	
	# Epsilon of adadelta
	"adadelta_epsilon": 1e-8
	"comment": "Epsilon of adadelta, useful when optimizer is "
	                      "Adadelta"

**Embedding Configs:**

	MODULE_NAME = "embedding_layer"
	# Input embedding dimension
	"embedding_dimension": 128
	"comment": "Dimension of word embedding."
	
	# Embedding initializer type
	VALID_EMBEDDING_INITIALIZER = ["uniform", "normal"]
	"embedding_initializer": "uniform"
	"comment": "Embedding_initializer can be: %s." % ",".join(
	           VALID_EMBEDDING_INITIALIZER)
	
	# Embedding bound when using uniform
	"embedding_uniform_bound": 0
	"comment": "If embedding_initializer is uniform, this param will be "
	           "used as bound. e.g."
	           "[-embedding_uniform_bound,embedding_uniform_bound]."
	           "If embedding_uniform_bound is 0, default bound will be"
	           "used, which is 1.0/pow(embedding_dimension, 0.5)"
	
	# The standard deviation of the random initialization of embedding
	"embedding_random_stddev": 0.01
	"comment": "If embedding_initializer is random, this param will be "
	           "used as stddev."
	
	# Embedding layer dropout
	"embedding_dropout_keep_prob": 1
	"comment": "Dropout prob of embedding."

**Model Configs:**

	MODULE_NAME = "model_common"
	# Model type
	VALID_MODEL_TYPE = ["FastText", "TextCNN", "TextRNN", "TextVDCNN", "RegionEmbedding", "AttentiveConvNet"]
	"model_type": "FastText"
	"comment": "Model type can be: %s" % ",".join(VALID_MODEL_TYPE)
	
	# Checkpoint dir
	"checkpoint_dir": "checkpoint"
	"comment": "Path to save checkpoint for estimator"
	
	# Models generated during training
	"export_model_dir": "export_model"
	"comment": "Path to export the final model"
	
	# Use attention or not, for the TextRNN model
	"use_self_attention": false
	"comment":  "Whether to use self attention. Can be use in TextRNN."
	
	# Attention dimension
	"attention_dimension": 32
	"comment": "Dimension of attention."
	
	# Activation function type
	VALID_ACTIVATION_TYPE = ["relu", "sigmoid", "tanh", "none"]
	"activation": "none"
	"comment": "Activation func at last layer can be: %s" % ",".join(
	           VALID_ACTIVATION_TYPE)

**Log Configs:**

	MODULE_NAME = "log"
	# Log dir
	"logger_file": "log"
	"comment": "Log file."
	
	# Log level
	"log_level": "warn"
	"comment": "Log level of logging and tf.logging, "
	           "candidate: debug, info, warn, error."
	           "Since tf.estimator's info log will cover some train "
	           "log, we set default log level warn and log level in "
	           "this project is equal or greater than warn."

**FastText Configs：**

**TextCNN Configs：**

	MODULE_NAME = "TextCNN"
	# Filter size
	"filter_sizes": "[1,2,3,4,5,6,7]"
	"comment": "Comma-separated filter sizes."
	
	# Number of filters
	"num_filters": 256
	"comment": "Number of filters per filter size."

**TextRNN Configs：**

	MODULE_NAME = "TextRNN"
	# RNN dimension
	"rnn_dimension": 128
	"comment": "Dimension of rnn."
	
	VALID_CELL_TYPE = ["gru", "lstm"]
	# RNN cell
	"cell_type": "lstm"
	"comment": "Rnn cell type can be: %s" % ",".join(VALID_CELL_TYPE)
	
	# Whether use Bi-RNN or not
	"use_bidirectional": true
	"comment": "If true, will use bidirectional rnn. "
	           "Else, use one way"

**VDCNN Configs：**

	MODULE_NAME = "TextVDCNN"
	# Depth of VDCNN, can be 9, 17, 29, 49
	"vdcnn_depth": 9
	"comment": "depth of vdcnn, can be 9, 17, 29, 49."

**RegionEmbedding Configs：**

	MODULE_NAME = "RegionEmbedding"
	# Region embeddingm mode
	"region_embedding_mode": "WC"	
	"comment": "Can be WC,CW;"	
	           "WC : Word-Context Region Embedding, "
	           "CW : Context-Word Region Embedding"
	
	# region size
	"region_size": 9
	"comment": "region size, must be odd number."
	           "region size means "
	           "how many tokens/chars one region covers"

**AttentiveConvNet Configs：**

	MODULE_NAME = "AttentiveConvNet"
	# Attentive width 
	"attentive_width": 3                                  
	"comment": "attentive_width, must be odd"
	
	# Attentive hidden size 
	"attentive_hidden_size": 500
	"comment": "attentive_hidden_size"
	
	# Attentive version
	"attentive_version": "light",
	"comment": "attentive_version: light, advanced"

**Evaluation Configs：**
	
	MODULE_NAME = "eval"
	# The probability threshold used in the evaluation,
    # it will be not evaluated when it is lower than or equal to this threshold.
	"threshold": 0
	"comment": "If max predict prob is less than or equal to threshold, "
	           "this example will not counted in precision calculation."

	# eval result dir
	"eval_dir": "eval_dir"
	"comment": "Path to output the detail performance on test set"
	
	# Whether the label is flat or not, if it is False, 
	# it indicates hierarchical classification, at this time, the evaluation performance will be hierarchically evaluated.
	"is_flat": true
	"comment": "Label is flat or not"
	
	# batch size of evaluation
	"batch_size": 128
	"comment": "Batch size of evaluation"
**Prediction Configs：**
	
	MODULE_NAME = "predict"
	# # model tag, can be "train", "serve", "gpu", "tpu", etc.
	"model_tag": "serve",
	"comment": "model tag added by user"
	
	# model dirs
	"model_dirs": "["export_model/1527501251", "export_model/1527501256"]"
	"comment": "model dirs"
	
	# model weights
	"model_weights": "[0.6, 0.4]"
	"comment": "model weights"

# 9. TODO #
- Data Input
	- Supports image features and multimodality
	- Supports floating point custom features
- Model
	- Supports Learning Structured Representation, Capsule Network, etc
	- More Attention types
- Loss Function
	- Supports loss function of hierarchical classification(such as Recursive Regularization)
- Classifcation Problem
	- Supports top-down hierarchical classification
- Online deployment
	- Open code of deployment Server

# 10. Acknowledgements #
The DeepText-Classification implementation process refers to some of the industry's open source code or open source tools, including hyperparameter settings, or partially quoted code.

1. https://github.com/yinwenpeng/Attentive_Convolution
2. https://github.com/text-representation/local-context-unit
3. https://github.com/brightmart/text_classification
4. https://github.com/zonetrooper32/VDCNN
5. https://github.com/NLPLearn/QANet

# Appendix-1 Performance in open datasets#
In order to verify the correctness of DeepText-Classification implementation, we used DeepText-Classification to reproduce the model and training method in the open datasets. The results are in line with the expectations. DeepText-Classification performed better on some datasets.

<table>
<tr align="middle"><th>TextCNN[Kim, Yoon,2014]<th>Number of class<th>Dataset size<th>Average length<th>Vocabulary size(w)<th>TextCNN-rand<th>TextCNN-static<th>TextCNN-non-static
<tr align="middle"><td>Movie Reviews <td>2<td>10662<td>20<td>1<td><font color=red>75.4(-0.7)<td><font color=red>80.6(-0.4)<td><font color=red>80.7(-0.8)
<tr align="middle"><td>SST-1 <td>5<td>11855<td>18<td>1<td><font color=green>46.4(+1.4)<td><font color=green>47.0(+1.5)<td><font color=green>50.0(+2.0)
<tr align="middle"><td>SST-2 <td>2<td>9613<td>19<td>1<td><font color=green>84.5(+1.8)<td><font color=red>86.7(-0.1)<td><font color=green>87.5(+0.3)
<tr align="middle"><td>Subj <td>2<td>10000<td>23<td>1<td><font color=green>89.7(+0.1)<td><font color=green>93.1(+0.1)<td><font color=red>93.0(-0.4)
<tr align="middle"><td>TREC <td>6<td>5952<td>10<td>0.6<td><font color=red>89.8(-1.4)<td><font color=red>92.6(-0.2)<td><font color=green>93.8(+0.2)
<tr align="middle"><td>CR <td>2<td>3775<td>19<td>0.37<td><font color=red>78.8(-1.0)<td><font color=red>83.5(-1.2)<td><font color=green>84.5(+0.2)
<tr align="middle"><td>MPQA <td>2<td>10606<td>3<td>1<td><font color=green>84.2(+0.8)<td><font color=red>89.5(-0.1)<td><font color=red>89.4(-0.1)
</table>

<table>
<tr align="middle"><th>FastText[Joulin, Armand, et al, 2016]<th>Number of class<th>Dataset size<th>Average length<th>Vocabulary size(w)<th>FastText(h=10)<th>FastText(h=10,bigram)
<tr align="middle"><td>AG's News<td>4<td>127,600<td>43<td>9<td><font color=green>91.9(+0.4)<td><font color=green>92.9(+0.4)
<tr align="middle"><td>Sogou News<td>5<td>510,000<td>577<td>36<td><font color=green>94.5(+0.6)<td><font color=green>96.8(+0.0)
<tr align="middle"><td>DBPedia<td>14<td>630,000<td>54<td>52<td><font color=green>98.2(+0.1)<td><font color=green>98.7(+0.1)
<tr align="middle"><td>Yelp Review Polarity<td>2<td>598,000<td>156<td>56<td><font color=green>94.1(+0.3)<td><font color=green>95.9(+0.2)
<tr align="middle"><td>Yelp Review Full<td>5<td>700,000<td>157<td>51<td><font color=green>60.5(+0.1)<td><font color=red>63.4(-0.5)
<tr align="middle"><td>Yahoo! Answers<td>10<td>1,460,000<td>111<td>190<td><font color=green>72.6(+0.6)<td><font color=green>73.4(+1.1)
<tr align="middle"><td>Amazon Review Full<td>5<td>3,650,000<td>94<td>140<td><font color=red>55.1(-0.7)<td><font color=green>60.4(+0.0)
<tr align="middle"><td>Amazon Review Polarity<td>2<td>4,000,000<td>92<td>150<td><font color=green>91.3(+0.1)<td><font color=green>94.8(+0.2)
</table>

# Appendix-2 Perfomance in the business #
We used DeepText-Classification to conduct experiments in real business scenarios, especially to distinguish more fine-grained categories beyond the existing Baseline effect. This section focuses on the experimental results of APP classification, ECC classification, and News classification.
## APP classifcation ##
The category system of the APP scene is divided into three levels. According to the mainstream application store in the industry, and combined with the needs of advertisers, a total of 340+ category nodes are created. The data set adopts a manual labeling plus rules generation method with a scale of approximately 300,000.
<table>
<tr align="middle"><td rowspan="2"><strong>Model\Performance<td colspan="3"><strong>Level 1<td colspan="3"><strong>Level 2<td colspan="3"><strong>Level 3
<tr align="middle"><td>Precision<td>Recall<td>F1-score<td>Precision<td>Recall<td>F1-score<td>Precision<td>Recall<td>F1-score
<tr align="middle"><td>Baseline1-TextMiner-MaxEnt<td>94.90%<td>94.90%<td>94.90%<td>88.93%<td>89.36%<td>89.14%<td>73.51%<td>85.64%<td>79.11%
<tr align="middle"><td>Baseline2-TextMiner-FastText<td>95.19%<td>95.19%<td>95.19%<td>89.27%<td>89.80%<td>89.54%<td>73.13%<td>83.31%<td>77.89%
<tr align="middle"><td>TextCNN-Token<td>96.94%<td>96.94%<td>96.94%<td>93.13%<td>93.33%<td>93.23%<td>88.06%<td>87.38%<td>87.72%
<tr align="middle"><td>TextCNN-Char<td>96.90%<td>96.90%<td>96.90%<td>92.89%<td>93.11%<td>93.00%<td>88.18%<td>87.17%<td>87.67%
<tr align="middle"><td>TextCNN-Token-Word2vec<td>96.96%<td>96.96%<td>96.96%<td>93.11%<td>93.33%<td>93.22%<td>88.30%<td>87.68%<td>87.99%
<tr align="middle"><td>TextCNN-Token-CWE<td>96.90%<td>96.90%<td>96.90%<td>93.10%<td>93.27%<td>93.18%<td>88.29%<td>87.55%<td>87.92%
<tr align="middle"><td>LightAttentiveConvolution<td>96.85%<td>96.85%<td>96.85%<td>92.94%<td>93.14%<td>93.04%<td>88.35%<td>87.60%<td>87.97%
<tr align="middle"><td>LightAttentiveConvolution-CWE<td>97.02%<td>97.02%<td>97.02%<td>93.30%<td>93.50%<td>93.40%<td>88.91%<td>88.25%<td>88.58%
<tr align="middle"><td>BiLSTM-Token<td>96.39%<td>96.39%<td>96.39%<td>91.38%<td>91.72%<td>91.55%<td>85.68%<td>85.28%<td>85.48%
<tr align="middle"><td>BiGRU-Token<td>96.58%<td>96.58%<td>96.58%<td>91.95%<td>92.10%<td>92.02%<td>87.34%<td>86.18%<td>86.76%
<tr align="middle"><td>BiLSTM-Token-Attention<td>96.83%<td>96.83%<td>96.83%<td>92.80%<td>93.03%<td>92.92%<td>87.27%<td>87.37%<td>87.32%
<tr align="middle"><td>BiGRU-Token-Attention<td>96.97%<td>96.97%<td>96.97%<td>92.97%<td>93.21%<td>93.09%<td>87.88%<td>87.43%<td>87.66%
<tr align="middle"><td>BiGRU-Token-Attention-Word2vec<td>96.86%<td>96.86%<td>96.86%<td>92.83%<td>93.08%<td>92.96%<td>87.25%<td>87.66%<td>87.46%
<tr align="middle"><td>BiGRU-Token-Attention-CWE<td>96.81%<td>96.81%<td>96.81%<td>92.69%<td>92.96%<td>92.82%<td>87.05%<td>86.45%<td>86.75%
<tr align="middle"><td>BiLSTM-Token-Attention-Word2vec<td>96.80%<td>96.80%<td>96.80%<td>92.52%<td>92.79%<td>92.65%<td>86.83%<td>86.38%<td>86.61%
<tr align="middle"><td>BiLSTM-Token-Attention-CWE<td>96.77%<td>96.77%<td>96.77%<td>92.53%<td>92.69%<td>92.61%<td>86.66%<td>86.56%<td>86.61%
<tr align="middle"><td>BiLSTM-Char<td>95.90%<td>95.90%<td>95.90%<td>90.40%<td>90.73%<td>90.57%<td>83.84%<td>84.00%<td>83.92%
<tr align="middle"><td>BiLSTM-Char-Attention<td>96.32%<td>96.32%<td>96.32%<td>91.95%<td>92.16%<td>92.06%<td>86.65%<td>86.24%<td>86.45%
<tr align="middle"><td>BiGRU-Char<td>96.24%<td>96.24%<td>96.24%<td>91.33%<td>91.63%<td>91.47%<td>84.80%<td>84.68%<td>84.74%
<tr align="middle"><td>BiGRU-Char-Attention<td>96.70%<td>96.70%<td>96.70%<td>92.38%<td>92.61%<td>92.49%<td>86.61%<td>87.07%<td>86.84%
<tr align="middle"><td>FastText(Token-Bigram)<td>94.75%<td>94.75%<td>94.75%<td>88.79%<td>88.79%<td>88.79%<td>81.53%<td>80.58%<td>81.05%
<tr align="middle"><td>FastText(Token-Trigram)<td>95.16%<td>95.16%<td>95.16%<td>89.21%<td>89.64%<td>89.42%<td>83.10%<td>81.57%<td>82.33%
<tr align="middle"><td>VDCNN(9)-Char<td>95.27%<td>95.27%<td>95.27%<td>90.11%<td>90.32%<td>90.22%<td>82.99%<td>82.42%<td>82.70%
<tr align="middle"><td>VDCNN(29)-Char<td>92.37%<td>92.37%<td>92.37%<td>84.81%<td>85.16%<td>92.37%<td>73.75%<td>74.65%<td>74.20%
<tr align="middle"><td>RegionEmbedding(WC,original code,seq_len=1024)<td>96.14%<td>96.14%<td>96.14%<td>91.32%<td>91.24%<td>91.28%<td>86.75%<td>85.37%<td>86.05%
<tr align="middle"><td>RegionEmbedding(CW,original code,seq_len=1024)<td>96.03%<td>96.03%<td>96.03%<td>90.96%<td>90.78%<td>90.87%<td>86.16%<td>84.66%<td>85.40%
<tr align="middle"><td>RegionEmbedding(multi-region,original code,seq_len=1024)<td>96.18%<td>96.18%<td>96.18%<td>91.48%<td>91.30%<td>91.39%<td>86.78%<td>85.16%<td>85.96%
<tr align="middle"><td>RegionEmbedding(WC.seq_len=256)<td>96.08%<td>96.08%<td>96.08%<td>91.11%<td>91.41%<td>91.26%<td>84.43%<td>84.06%<td>84.24%
<tr align="middle"><td>RegionEmbedding(WC.seq_len=512)<td>96.19%<td>96.19%<td>96.19%<td>91.11%<td>91.32%<td>91.22%<td>85.31%<td>84.12%<td>84.71%
<tr align="middle"><td>RegionEmbedding(WC.seq_len=1024)<td>96.14%<td>96.14%<td>96.14%<td>91.50%<td>91.70%<td>91.60%<td>86.23%<td>84.27%<td>85.24%
<tr align="middle"><td>RegionEmbedding(CW.seq_len=256)<td>96.01%<td>96.01%<td>96.01%<td>90.98%<td>91.18%<td>91.08%<td>85.46%<td>84.33%<td>84.89%
<tr align="middle"><td>RegionEmbedding(CW.seq_len=512)<td>95.81%<td>95.81%<td>95.81%<td>90.90%<td>91.18%<td>91.04%<td>85.72%<td>83.63%<td>84.66%
<tr align="middle"><td>RegionEmbedding(CW.seq_len=1024)<td>96.00%<td>96.00%<td>96.00%<td>91.45%<td>91.58%<td>91.51%<td>85.97%<td>84.32%<td>85.14%
<tr align="middle"><td>RegionEmbedding(WC)+Word2vec<td>96.10%<td>96.10%<td>96.10%<td>91.22%<td>91.31%<td>91.26%<td>85.60%<td>84.56%<td>85.08%
<tr align="middle"><td>RegionEmbedding(CW)+Word2vec<td>96.04%<td>96.04%<td>96.04%<td>91.10%<td>91.28%<td>91.19%<td>85.24%<td>83.76%<td>84.49%
<tr align="middle"><td>RegionEmbedding(WC)-CWE<td>96.05%<td>96.05%<td>96.05%<td>90.92%<td>91.11%<td>91.02%<td>85.09%<td>84.00%<td>84.54%
<tr align="middle"><td>RegionEmbedding(CW)-CWE<td>96.03%<td>96.03%<td>96.03%<td>90.81%<td>91.07%<td>90.94%<td>85.63%<td>83.21%<td>84.40%
<tr align="middle"><td>RegionEmbedding(WC.seq_len=256)+TextCNN(concat wordembedding)<td>97.31%<td>97.31%<td>97.31%<td>93.83%<td>94.04%<td>93.94%<td>88.68%<td>88.75%<td>88.71%
<tr align="middle"><td>RegionEmbedding(WC.seq_len=512)+TextCNN(concat wordembedding)<td>97.49%<td>97.49%<td>97.49%<td>94.22%<td>94.47%<td>94.35%<td>89.86%<td>88.82%<td>89.34%
<tr align="middle"><td>RegionEmbedding(WC.seq_len=1024)+TextCNN(concat wordembedding)<td>97.40%<td>97.40%<td>97.40%<td>94.30%<td>94.37%<td>94.34%<td>89.97%<td>89.24%<td>89.60%
<tr align="middle"><td>RegionEmbedding(CW)+TextCNN(replace wordembedding)<td>96.53%<td>96.53%<td>96.53%<td>92.67%<td>92.76%<td>92.72%<td>87.06%<td>85.48%<td>86.26%
<tr align="middle"><td>RegionEmbedding(CW.seq_len=256)+TextCNN(concat wordembedding)<td>97.47%<td>97.47%<td>97.47%<td>94.04%<td>94.14%<td>94.09%<td>89.32%<td>88.60%<td>88.96%
<tr align="middle"><td>RegionEmbedding(CW.seq_len=512)+TextCNN(concat wordembedding)<td>97.50%<td>97.50%<td>97.50%<td>94.34%<td>94.58%<td>94.46%<td><strong>90.37%<td><strong>89.29%<td><strong>89.83%
<tr align="middle"><td>RegionEmbedding(CW.seq_len=1024)+TextCNN(concat wordembedding)<td>97.46%<td>97.46%<td>97.46%<td>94.27%<td>94.38%<td>94.32%<td>89.79%<td>89.36%<td>89.57%
<tr align="middle"><td>RegionEmbedding(WC)+TextCNN(concat)+Word2vec<td>97.46%<td>97.46%<td>97.46%<td>94.20%<td>94.37%<td>94.28%<td>89.07%<td>89.75%<td>89.41%
<tr align="middle"><td>RegionEmbedding(CW)+TextCNN(concat)+Word2vec<td>97.49%<td>97.49%<td>97.49%<td>94.35%<td>94.55%<td>94.45%<td>89.28%<td>89.40%<td>89.34%
<tr align="middle"><td>RegionEmbedding(WC)+TextCNN(concat)-CWE<td><strong>97.56%<td><strong>97.56%<td><strong>97.56%<td><strong>94.47%<td><strong>94.52%<td><strong>94.49%<td>90.25%<td>89.11%<td>89.68%
<tr align="middle"><td>RegionEmbedding(CW)+TextCNN(concat)-CWE<td>97.54%<td>97.54%<td>97.54%<td>94.22%<td>94.40%<td>94.31%<td>89.78%<td>89.79%<td>89.79%
</table>
Note: TextMiner is a self-developed top-down hierarchical classification tool

## ECC classifcation ##
The e-commerce category system is divided into three levels, based on the industry's mainstream e-commerce system, and combined with the needs of advertisers to develop a total of 130 + category nodes. The data set was built using automatic crawling, with a scale of about 20 million.
<table>
<tr align="middle"><td rowspan="2"><strong>Model\Performance<td colspan="3"><strong>Level 1<td colspan="3"><strong>Level 2<td colspan="3"><strong>Level 3
<tr align="middle"><td>Precision<td>Recall<td>F1-score<td>Precision<td>Recall<td>F1-score<td>Precision<td>Recall<td>F1-score
<tr align="middle"><td>Baseline-TextMiner-FastText<td><strong>94.98%<td><strong>94.91%<td><strong>94.94%<td><strong>91.50%<td><strong>91.43%<td><strong>91.46%<td>86.35%<td>89.65%<td>87.97%
<tr align="middle"><td>FastText(Token-TokenNgram)<td>93.91%<td>93.91%<td>93.91%<td>87.51%<td>87.51%<td>87.51%<td>84.87%<td>85.59%<td>85.23%
<tr align="middle"><td>FastText(Token-TokenNgram-custom_feature(lda))<td>93.81%<td>93.81%<td>93.81%<td>87.65%<td>87.65%<td>87.65%<td>85.02%<td>85.66%<td>85.34%
<tr align="middle"><td>CNN-Char<td>93.65%<td>93.65%<td>93.65%<td>89.39%<td>89.39%<td>89.39%<td>87.18%<td>87.32%<td>87.25%
<tr align="middle"><td>CNN-Token<td>94.39%<td>94.39%<td>94.39%<td>90.13%<td>90.13%<td>90.13%<td>87.98%<td>87.96%<td>87.97%
<tr align="middle"><td>CNN-Token-Word2vec<td>94.41%<td>94.41%<td>94.41%<td>90.91%<td>90.91%<td>90.91%<td>88.58%<td>88.33%<td>88.46%
<tr align="middle"><td>CNN-Token-CWE<td>94.54%<td>94.54%<td>94.54%<td>90.36%<td>90.36%<td>90.36%<td>88.08%<td>88.00%<td>88.04%
<tr align="middle"><td>BiLSTM-Token<td>93.12%<td>93.12%<td>93.12%<td>87.35%<td>87.35%<td>87.35%<td>84.69%<td>85.08%<td>84.89%
<tr align="middle"><td>BiLSTM-Token-Attention<td>93.50%<td>93.50%<td>93.50%<td>89.33%<td>89.33%<td>89.33%<td>87.14%<td>87.25%<td>87.19%
<tr align="middle"><td>BiLSTM-Token-Attention-Word2vec<td>94.09%<td>94.09%<td>94.09%<td>89.04%<td>89.04%<td>89.04%<td>86.73%<td>86.98%<td>86.85%
<tr align="middle"><td>BiLSTM-Token-Attention-CWE<td>94.08%<td>94.08%<td>94.08%<td>89.39%<td>89.39%<td>89.39%<td>87.23%<td>87.28%<td>87.25%
<tr align="middle"><td>BiLSTM-Char<td>93.96%<td>93.96%<td>93.96%<td>88.90%<td>88.90%<td>88.90%<td>86.73%<td>86.91%<td>86.82%
<tr align="middle"><td>VDCNN(Char)-9<td>93.24%<td>93.24%<td>93.24%<td>88.34%<td>88.34%<td>88.34%<td>86.06%<td>85.84%<td>85.95%
<tr align="middle"><td>VDCNN(Char)-17<td>92.46%<td>92.46%<td>92.46%<td>86.72%<td>86.72%<td>86.72%<td>85.73%<td>84.62%<td>85.17%
<tr align="middle"><td>AttentiveConvNet-light<td>94.20%<td>94.20%<td>94.20%<td>90.55%<td>90.55%<td>90.55%<td>88.41%<td>88.25%<td>88.33%
<tr align="middle"><td>AttentiveConvNet-light-Word2vec<td>94.44%<td>94.44%<td>94.44%<td>90.82%<td>90.82%<td>90.82%<td>88.54%<td>88.33%<td>88.44%
<tr align="middle"><td>LightAttentiveConvNet-light-CWE<td>94.60%<td>94.60%<td>94.60%<td>91.02%<td>91.02%<td>91.02%<td><strong>88.88%<td><strong>88.64%<td><strong>88.76%
</table>

## News classifcation ##
The category system of the news scene is divided into four levels, a total of 800+ category nodes covering the entire industry. The data set is manually annotated with a scale of about 500,000.
<table>
<tr align="middle"><td rowspan="2"><strong>Model\Performance<td colspan="3"><strong>Level 1<td colspan="3"><strong>Level 2<td colspan="3"><strong>Level 3<td colspan="3"><strong>Level 4
<tr align="middle"><td>Precision<td>Recall<td>F1-score<td>Precision<td>Recall<td>F1-score<td>Precision<td>Recall<td>F1-score<td>Precision<td>Recall<td>F1-score
<tr align="middle"><td>Baseline1-TextMiner-FastText<td>85.81%<td><strong>73.02%<td><strong>78.90%<td>75.95%<td><strong>64.65%<td><strong>69.85%<td>56.30%<td><strong>74.44%<td>64.11%<td>59.76%<td><strong>65.33%<td>62.42%
<tr align="middle"><td>Baseline2-TextMiner-MaxEnt<td>82.36%<td>64.43%<td>72.30%<td>72.77%<td>56.73%<td>63.76%<td>56.06%<td>82.22%<td>66.67%<td>51.65%<td>62.67%<td>56.63%
<tr align="middle"><td>FastText(Token-Bigram)<td><strong>89.41%<td>49.52%<td>63.74%<td><strong>81.14%<td>45.06%<td>57.94%<td>84.31%<td>47.77%<td>60.99%<td>81.08%<td>40.00%<td>53.57%
<tr align="middle"><td>FastText(Token-Bigram-Word2vec)<td>88.25%<td>51.13%<td>64.75%<td>80.13%<td>46.54%<td>58.88%<td>84.00%<td>46.67%<td>60.00%<td>84.62%<td>44.00%<td>57.89%
<tr align="middle"><td>FastText(Token-Trigram)<td>88.71%<td>49.81%<td>63.80%<td>79.66%<td>44.84%<td>57.38%<td>81.63%<td>44.44%<td>57.55%<td>82.85%<td>38.66%<td>52.72%
<tr align="middle"><td>CNN-Char<td>75.37%<td>58.16%<td>65.65%<td>64.19%<td>49.65%<td>55.99%<td>61.29%<td>42.22%<td>50.00%<td>58.97%<td>30.67%<td>40.35%
<tr align="middle"><td>CNN-Token<td>80.65%<td>50.21%<td>61.89%<td>70.07%<td>43.74%<td>53.86%<td>50.00%<td>35.55%<td>41.55%<td>57.14%<td>26.66%<td>36.36%
<tr align="middle"><td>CNN-Token-Word2vec<td>82.03%<td>60.29%<td>69.50%<td>72.64%<td>53.52%<td>61.63%<td>70.51%<td>61.11%<td>65.48%<td>70.69%<td>54.67%<td>61.65%
<tr align="middle"><td>BiLSTM-Token<td>84.44%<td>54.49%<td>66.23%<td>74.28%<td>48.05%<td>58.35%<td>57.53%<td>46.67%<td>51.53%<td>58.70%<td>36.00%<td>44.63%
<tr align="middle"><td>BiLSTM-Token-Attention<td>82.98%<td>59.37%<td>69.22%<td>73.60%<td>52.79%<td>61.49%<td>65.67%<td>48.88%<td>56.05%<td>70.45%<td>41.33%<td>52.10%
<tr align="middle"><td>BiLSTM-Token-Attention-Word2vec<td>85.31%<td>61.23%<td>71.29%<td>75.92%<td>54.62%<td>63.53%<td>65.08%<td>45.56%<td>53.59%<td>57.78%<td>34.67%<td>43.33%
<tr align="middle"><td>BiLSTM-Char<td>79.40%<td>60.70%<td>68.80%<td>69.39%<td>53.18%<td>60.21%<td>53.16%<td>46.67%<td>49.70%<td>47.06%<td>32.00%<td>38.10%
<tr align="middle"><td>BiLSTM-Char-Attention<td>81.76%<td>60.19%<td>69.34%<td>71.79%<td>52.99%<td>60.97%<td>61.54%<td>44.44%<td>51.61%<td>65.12%<td>37.33%<td>47.46%
<tr align="middle"><td>BiGRU-Token-Attention<td>86.74%<td>52.92%<td>65.73%<td>76.76%<td>46.95%<td>58.26%<td>72.00%<td>40.00%<td>51.43%<td>75.00%<td>36.00%<td>48.65%
<tr align="middle"><td>BiGRU-Token-Attention-Word2vec<td>83.60%<td>61.23%<td>70.69%<td>74.52%<td>54.72%<td>63.10%<td>71.76%<td>67.78%<td>69.71%<td>62.32%<td>57.33%<td>59.72%
<tr align="middle"><td>RegionEmbedding(WC)<td>82.17%<td>45.11%<td>58.24%<td>72.63%<td>39.97%<td>51.56%<td>69.23%<td>30.00%<td>41.86%<td>68.18%<td>20.00%<td>30.93%
<tr align="middle"><td>CNN-Token(seq_len=512)<td>84.11%<td>55.14%<td>66.62%<td>75.55%<td>49.65%<td>59.92%<td>66.67%<td>46.67%<td>54.90%<td>73.17%<td>40.00%<td>51.72%
<tr align="middle"><td>RegionEmbedding(WC)+CNN<td>84.30%<td>56.09%<td>67.36%<td>75.01%<td>50.03%<td>60.03%<td>74.60%<td>52.22%<td>61.44%<td>76.74%<td>44.00%<td>55.93%
<tr align="middle"><td>AttentiveConvNet-light<td>76.96%<td>47.99%<td>59.12%<td>66.05%<td>41.29%<td>50.81%<td>78.00%<td>43.33%<td>55.71%<td>74.36%<td>38.67%<td>50.88%
</table>

# Appendix-3 SMP evaluation #
We participated in the 7th National Social Media Processing Conference User Portrait Technical Evaluation (SMP-EUPT 2018) - jinritoutiao's author portrait evaluation. Using DeepText-Classification, we finally won the second place(2/39).
<table>
<tr align="middle"><td><strong>LB<strong><td><strong>Ranking<td colspan="1"><strong>All Categories<td colspan="1"><strong>Human Author<td colspan="1"><strong>Machine Author<td colspan="1"><strong>Machine Translation<td colspan="1"><strong>Machine Summary
<tr align="middle"><td>Public<td>3<td>0.98889<td>0.9838760339231494<td>0.9990772316950853<td>0.9958557811852466<td>0.9767497698987554
<tr align="middle"><td>Private<td>2<td>0.98830<td>0.9826671105975441<td>0.9992176686525847<td>0.9958310676092079<td>0.9748279608837377
</table>

# Appendix-4 References #
1.	Joulin, Armand, et al. "Bag of tricks for efficient text classification." arXiv preprint arXiv:1607.01759 (2016).
2.	Joulin, Armand, et al. "Fasttext. zip: Compressing text classification models." arXiv preprint arXiv:1612.03651 (2016).
3.	Bojanowski, Piotr, et al. "Enriching word vectors with subword information." arXiv preprint arXiv:1607.04606 (2016).
4.	Kim, Yoon. "Convolutional neural networks for sentence classification." arXiv preprint arXiv:1408.5882 (2014).
5.	Zhang, Ye, and Byron Wallace. "A sensitivity analysis of (and practitioners' guide to) convolutional neural networks for sentence classification." arXiv preprint arXiv:1510.03820(2015).
6.	Lai, Siwei, et al. "Recurrent Convolutional Neural Networks for Text Classification." AAAI. Vol. 333. 2015.
7.	Yang, Zichao, et al. "Hierarchical attention networks for document classification." Proceedings of the 2016 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies. 2016.
8.	Chao Qiao, Bo Huang, et al. “A new method of region embedding for text classification.” ICLR 2018.
9.	Yin, Wenpeng, and Hinrich Schütze. "Attentive Convolution."arXiv preprint arXiv:1710.00519 (2017).
10.	Yang Liu, Mirella Lapata. “Learning Structured Text Representations”. arXiv preprint arXiv: arXiv:1705.09207(2017)
11.	Conneau, Alexis, et al. "Very deep convolutional networks for text classification." Proceedings of the 15th Conference of the European Chapter of the Association for Computational Linguistics: Volume 1, Long Papers. Vol. 1. 2017.
12.	Zhang, Xiang, Junbo Zhao, and Yann LeCun. "Character-level convolutional networks for text classification." Advances in neural information processing systems. 2015.
13.	http://theorangeduck.com/page/neural-network-not-working
14.	http://ruder.io/deep-learning-nlp-best-practices/
15.	Bahdanau, Dzmitry, Kyunghyun Cho, and Yoshua Bengio. "Neural machine translation by jointly learning to align and translate." arXiv preprint arXiv:1409.0473 (2014).
16.	Liu, Pengfei, Xipeng Qiu, and Xuanjing Huang. "Recurrent neural network for text classification with multi-task learning."arXiv preprint arXiv:1605.05101 (2016).
17.	Mikolov, Tomas, et al. "Efficient estimation of word representations in vector space." arXiv preprint arXiv:1301.3781 (2013).
18.	Mikolov, Tomas, et al. "Distributed representations of words and phrases and their compositionality." Advances in neural information processing systems. 2013.
19.	Johnson, Rie, and Tong Zhang. "Deep pyramid convolutional neural networks for text categorization." Proceedings of the 55th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers). Vol. 1. 2017.
20.	Lin, Tsung-Yi, et al. "Focal loss for dense object detection."arXiv preprint arXiv:1708.02002 (2017).
21.	Zhang, Honglun, et al. "Multi-Task Label Embedding for Text Classification." arXiv preprint arXiv:1710.07210 (2017).
22.	Howard, Jeremy, and Sebastian Ruder. "Fine-tuned Language Models for Text Classification." arXiv preprint arXiv:1801.06146(2018).
23.	Yogatama, Dani, et al. "Generative and discriminative text classification with recurrent neural networks." arXiv preprint arXiv:1703.01898 (2017).
24.	Cheng, Heng-Tze, et al. "TensorFlow Estimators: Managing Simplicity vs. Flexibility in High-Level Machine Learning Frameworks." Proceedings of the 23rd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining. ACM, 2017.
25.	Gong, Linyuan, and Ruyi Ji. "What Does a TextCNN Learn?." arXiv preprint arXiv:1801.06287 (2018).
26.	Deep Learning Approach for Extreme Multi-label Text Classification, https://www.youtube.com/watch?v=yp01hpk1g4A
27.	Liu, Jingzhou, et al. "Deep Learning for Extreme Multi-label Text Classification." Proceedings of the 40th International ACM SIGIR Conference on Research and Development in Information Retrieval. ACM, 2017.
28.	Zhang, Tianyang, Minlie Huang, and Li Zhao. "Learning Structured Representation for Text Classification via Reinforcement Learning." (2018).
29.	Kiela, Douwe, et al. "Efficient Large-Scale Multi-Modal Classification." arXiv preprint arXiv:1802.02892 (2018).
30.	Le, Hoa T., Christophe Cerisara, and Alexandre Denis. "Do Convolutional Networks need to be Deep for Text Classification?." arXiv preprint arXiv:1707.04108 (2017).
31.	Zhao, Wei, et al. "Investigating Capsule Networks with Dynamic Routing for Text Classification." arXiv preprint arXiv:1804.00538 (2018).
32.	Yu, Adams Wei, et al. "QANet: Combining Local Convolution with Global Self-Attention for Reading Comprehension." arXiv preprint arXiv:1804.09541 (2018).
33.	Ashish Vaswani, Noam Shazeer, et al. "Attention Is All You Need." arXiv preprint arXir:1706.03762  (2017). 
34.	Baoxin Wang. "Disconnected Recurrent Neural Networks for Text Categorization." ACL (2018).
35.	Gopal, Siddharth, and Yiming Yang. "Recursive regularization for large-scale classification with hierarchical and graphical dependencies." Proceedings of the 19th ACM SIGKDD international conference on Knowledge discovery and data mining. ACM, 2013.
36.	Peng, Hao, et al. "Large-Scale Hierarchical Text Classification with Recursively Regularized Deep Graph-CNN." Proceedings of the 2018 World Wide Web Conference on World Wide Web. International World Wide Web Conferences Steering Committee, 2018.
37.	Peters, Matthew E., et al. "Deep contextualized word representations." arXiv preprint arXiv:1802.05365 (2018).
38.	Howard, Jeremy, and Sebastian Ruder. "Universal language model fine-tuning for text classification." Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers). Vol. 1. 2018.
39.	Peters, Matthew E., et al. "Deep contextualized word representations." arXiv preprint arXiv:1802.05365 (2018).