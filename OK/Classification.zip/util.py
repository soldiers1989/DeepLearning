#!usr/bin/env python
# coding:utf8

# Copyright (c) 2018, Tencent. All rights reserved

import logging

import tensorflow as tf

LABEL_SEPARATOR = "--"
CHARSET = "utf-8"
EPS = 1e-7


class Logger(object):
    _instance = None

    def __new__(cls, *args, **kw):
        if not cls._instance:
            cls._instance = super(Logger, cls).__new__(cls)
        return cls._instance

    def __init__(self, config):
        if config.log.log_level == "debug":
            logging_level = logging.DEBUG
            tf_logging_level = tf.logging.DEBUG
        elif config.log.log_level == "info":
            logging_level = logging.INFO
            tf_logging_level = tf.logging.INFO
        elif config.log.log_level == "warn":
            logging_level = logging.WARN
            tf_logging_level = tf.logging.WARN
        elif config.log.log_level == "error":
            logging_level = logging.ERROR
            tf_logging_level = tf.logging.ERROR
        else:
            raise TypeError(
                "No logging type named %s, candidate is: info, debug, error")
        logging.basicConfig(filename=config.log.logger_file,
                            level=logging_level,
                            format='%(asctime)s : %(levelname)s  %(message)s',
                            filemode="a", datefmt='%Y-%m-%d %H:%M:%S')
        tf.logging.set_verbosity(tf_logging_level)

    @staticmethod
    def debug(msg):
        """Log debug message
            msg: Message to log
        """
        tf.logging.debug(msg)

    @staticmethod
    def info(msg):
        """"Log info message
            msg: Message to log
        """
        tf.logging.info(msg)

    @staticmethod
    def warn(msg):
        """Log warn message
            msg: Message to log
        """
        tf.logging.warn(msg)

    @staticmethod
    def error(msg):
        """Log error message
            msg: Message to log
        """
        tf.logging.error(msg)

    @staticmethod
    def flush():
        """Log flush message
            msg: Message to log
        """
        tf.logging.flush()
