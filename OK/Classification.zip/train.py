#!usr/bin/env python
# coding:utf8

# Copyright (c) 2018, Tencent. All rights reserved

# Train and evaluate model.
# Usage: train.py config.json

import codecs
import os
import sys
import time

import tensorflow as tf

import util
from config import Config
from data_processor import DataProcessor
from evaluate import Evaluator
from model.attentive_convolution import AttentiveConvNetEstimator
from model.fasttext import FastTextEstimator
from model.model_helper import ModelHelper
from model.region_embedding import RegionEmbeddingEstimator
from model.text_cnn import TextCNNEstimator
from model.text_dpcnn import TextDPCNNEstimator
from model.text_drnn import TextDRNNEstimator
from model.text_rnn import TextRNNEstimator
from model.text_vdcnn import TextVDCNNEstimator

# Just prevent auto-reformat-code of pycharm from deleting import
TextRNNEstimator, FastTextEstimator, TextCNNEstimator, TextVDCNNEstimator, \
RegionEmbeddingEstimator, AttentiveConvNetEstimator, TextDPCNNEstimator, \
TextDRNNEstimator


def get_standard_label(file):
    """Get the standard label of validation and test file
    Text format: Label
    Label could be flattened or hierarchical which is separated by "--".
    Args:
        file: File to read
    Return:
        label_list
    """
    label_list = []
    for line in codecs.open(file, "r", encoding=util.CHARSET):
        label_list.append(line.strip("\n").split("\t")[0])
    return label_list


def eval_predict(estimator, data_processor, train_tfrecord_file, evaluator,
                 labels, logger, stage, config, log=True):
    probs = estimator.predict(
        input_fn=lambda: data_processor.dataset_input_fn(
            tf.estimator.ModeKeys.PREDICT, train_tfrecord_file,
            config.train.predict_batch_size, 1), hooks=None)
    (_, precision_list, recall_list, fscore_list, right_list,
     predict_list, standard_list) = \
        evaluator.evaluate(
            probs, labels, data_processor.label_map,
            threshold=config.eval.threshold,
            is_flat=config.eval.is_flat)
    log_str = "%s performance, precision: %f, recall: %f, " \
              "f1: %f, right: %d, predict: %d, standard: %d" % (
                  stage, precision_list[0][evaluator.MICRO_AVERAGE],
                  recall_list[0][evaluator.MICRO_AVERAGE],
                  fscore_list[0][evaluator.MICRO_AVERAGE],
                  right_list[0][evaluator.MICRO_AVERAGE],
                  predict_list[0][evaluator.MICRO_AVERAGE],
                  standard_list[0][evaluator.MICRO_AVERAGE])
    if log:
        logger.warn(log_str)
    return fscore_list[0][evaluator.MICRO_AVERAGE], log_str


def train():
    config = Config(config_file=sys.argv[1])
    logger = util.Logger(config)
    data_processor = DataProcessor(config)
    evaluator = Evaluator(config.eval.eval_dir)
    if os.path.exists(
            config.data.tfrecord_dir + "/" + os.path.basename(
                config.data.train_text_file) + ".tfrecord"):
        logger.warn(
            "Data has been processed before. Directly read from %s" %
            config.data.tfrecord_dir)
        data_processor.load_all_dict()
    else:
        logger.warn("Processed text files")
        data_processor.process_from_text_file()
    params = dict()
    params["label_size"] = len(data_processor.label_map)
    params["feature_names"] = config.feature_common.feature_names.split(",")
    if config.train.track_timeline:
        timeline_dir = config.model_common.checkpoint_dir + "/timeline/"
        if not os.path.exists(timeline_dir):
            os.makedirs(timeline_dir)
        hook = [tf.train.ProfilerHook(save_steps=1000, output_dir=timeline_dir)]
    else:
        hook = None
    assert config.model_common.model_type in ModelHelper.VALID_MODEL_TYPE
    model_name = config.model_common.model_type + "Estimator"
    train_tfrecord_file = data_processor.train_file
    validate_tfrecord_file = data_processor.validate_file
    test_tfrecord_file = data_processor.test_file
    train_labels = get_standard_label(data_processor.train_feature_file)
    validate_labels = get_standard_label(data_processor.validate_feature_file)
    test_labels = get_standard_label(data_processor.test_feature_file)

    best_validate_fscore = 0
    test_log_str = ""
    start_time = time.time()
    for i in range(1, config.train.num_epochs + 1):
        if i <= config.train.num_epochs_static_embedding:
            params["static_embedding"] = True
        else:
            params["static_embedding"] = False
        params["epoch"] = i
        estimator = globals()[model_name](data_processor, params)
        logger.warn("Start training epoch %d" % i)
        estimator.train(input_fn=lambda: data_processor.dataset_input_fn(
            tf.estimator.ModeKeys.TRAIN, train_tfrecord_file,
            config.train.batch_size,
            1), hooks=hook)
        logger.warn("Start evaluate at epoch %d" % i)
        if config.train.eval_train_data:
            eval_predict(estimator, data_processor, train_tfrecord_file,
                         evaluator, train_labels, logger, "Epoch %d train" % i,
                         config)
        fscore, _ = eval_predict(
            estimator, data_processor, validate_tfrecord_file, evaluator,
            validate_labels, logger, "Epoch %d validate" % i, config)
        if fscore > best_validate_fscore:
            best_validate_fscore = fscore
            _, test_log_str = eval_predict(
                estimator, data_processor, test_tfrecord_file, evaluator,
                test_labels, logger, "Best test", config, False)
            evaluator.save()
        estimator.export_savedmodel(config.model_common.export_model_dir,
                                    data_processor.serving_input_receiver_fn)
        time_used = time.time() - start_time
        start_time = time.time()
        logger.warn("Epoch %d cost time: %d second" % (i, time_used))
    logger.warn(test_log_str)


def main(_):
    train()


if __name__ == '__main__':
    tf.app.run()
