#!usr/bin/env python
# coding:utf8

# Copyright (c) 2018, Tencent. All rights reserved

# Provide function that calculate the precision, recall, F1-score
#   and output confusion_matrix.

# Usage:
# python evaluate.py config.json


import codecs
import json
import math
import os
import sys

import numpy as np
import tensorflow as tf

import util
from config import Config
from predict import Predictor


class Evaluator(object):
    MACRO_AVERAGE = "macro_average"
    MICRO_AVERAGE = "micro_average"
    """Not thread safe, will keep the latest eval result
    """

    def __init__(self, eval_dir):
        self.confusion_matrix_list = None
        self.precision_list = None
        self.recall_list = None
        self.fscore_list = None
        self.right_list = None
        self.predict_list = None
        self.standard_list = None

        self.eval_dir = eval_dir
        if not os.path.exists(self.eval_dir):
            os.makedirs(self.eval_dir)

    @staticmethod
    def _calculate_prf(right_count, predict_count, standard_count):
        """Calculate precision, recall, fscore
        Args:
            standard_count: Standard count
            predict_count: Predict count
            right_count: Right count
        Returns:
            precision, recall, f_score
        """
        precision, recall, f_score = 0, 0, 0
        if predict_count > 0:
            precision = right_count / predict_count
        if standard_count > 0:
            recall = right_count / standard_count
        if precision + recall > 0:
            f_score = precision * recall * 2 / (precision + recall)

        return precision, recall, f_score

    def calculate_level_performance(
            self, id_to_label_map, right_count_category, predict_count_category,
            standard_count_category, other_text='其他',
            exclude_method="contain"):
        """Calculate the level performance.
        Args:
            id_to_label_map: Label id to label name.
            other_text: Text to judge the other label.
            right_count_category: Right count.
            predict_count_category: Predict count.
            standard_count_category: Standard count.
            exclude_method: The method to judge the other label. Can be
                            contain(label_name contains other_text) or
                            start(label_name start with other_text).
        Returns:
            precision_dict, recall_dict, fscore_dict.
        """
        other_label = dict()
        for label_id, label_name in id_to_label_map.items():
            if exclude_method == "contain":
                if other_text in label_name:
                    other_label[label_name] = 1
            elif exclude_method == "start":
                if label_name.startswith(other_text):
                    other_label[label_name] = 1
            else:
                raise TypeError("Cannot find exclude_method: " + exclude_method)

        precision_dict = dict()
        recall_dict = dict()
        fscore_dict = dict()
        precision_dict[self.MACRO_AVERAGE] = 0
        recall_dict[self.MACRO_AVERAGE] = 0
        fscore_dict[self.MACRO_AVERAGE] = 0
        right_total = 0
        predict_total = 0
        standard_total = 0

        for label_id, label_name in id_to_label_map.items():
            if label_name in other_label:
                continue
            (precision_dict[label_name], recall_dict[label_name],
             fscore_dict[label_name]) = self._calculate_prf(
                right_count_category[label_name],
                predict_count_category[label_name],
                standard_count_category[label_name])
            right_total += right_count_category[label_name]
            predict_total += predict_count_category[label_name]
            standard_total += standard_count_category[label_name]
            precision_dict[self.MACRO_AVERAGE] += precision_dict[label_name]
            recall_dict[self.MACRO_AVERAGE] += recall_dict[label_name]
            fscore_dict[self.MACRO_AVERAGE] += fscore_dict[label_name]
        num_label_eval = len(id_to_label_map) - len(other_label)

        precision_dict[self.MACRO_AVERAGE] = \
            precision_dict[self.MACRO_AVERAGE] / num_label_eval
        recall_dict[self.MACRO_AVERAGE] = \
            recall_dict[self.MACRO_AVERAGE] / num_label_eval
        fscore_dict[self.MACRO_AVERAGE] = 0 \
            if (recall_dict[self.MACRO_AVERAGE] +
                precision_dict[self.MACRO_AVERAGE]) == 0 else \
            2 * precision_dict[self.MACRO_AVERAGE] * \
            recall_dict[self.MACRO_AVERAGE] / \
            (recall_dict[self.MACRO_AVERAGE]
             + precision_dict[self.MACRO_AVERAGE])

        right_count_category[self.MICRO_AVERAGE] = right_total
        predict_count_category[self.MICRO_AVERAGE] = predict_total
        standard_count_category[self.MICRO_AVERAGE] = standard_total

        (precision_dict[self.MICRO_AVERAGE], recall_dict[self.MICRO_AVERAGE],
         fscore_dict[self.MICRO_AVERAGE]) = \
            self._calculate_prf(right_total, predict_total, standard_total)
        return precision_dict, recall_dict, fscore_dict

    def evaluate(self, predicts, labels, label_map=None, threshold=0,
                 is_prob=True, is_flat=False, other_text='其他'):
        """Eval the predict result.
        Args:
            predicts: Predict probability or
                      predict text label(is_prob is false).
            labels: Standard label.
            label_map: Label dict. If is_prob is false and label_map is None,
                       label_map will be generated using labels.
            threshold: Threshold to filter probs.
            is_prob: The predict is prob list or label id.
            is_flat: If true, only calculate flat result.
                     Else, calculate hierarchical result.
            other_text: Label name contains other_text will not be calculate.
        Returns:
            confusion_matrix_list contain all result,
            filtered_confusion_matrix_list contains result that max predict prob
                is greater than threshold and will be used to calculate prf,
            precision_list, recall_list, fscore_list,
            right_count_list, predict_count_list, standard_count_list
        """

        def _init_confusion_matrix(label_map):
            """Init confusion matrix.
            Args:
                label_map: Label map.
            Returns:
                confusion_matrix.
            """
            confusion_matrix = dict()
            for label_name in label_map.keys():
                confusion_matrix[label_name] = dict()
                for label_name_other in label_map.keys():
                    confusion_matrix[label_name][label_name_other] = 0
            return confusion_matrix

        def _init_count_dict(label_map):
            """Init count dict.
            Args:
                label_map: Label map.
            Returns:
                count_dict.
            """
            count_dict = dict()
            for label_name in label_map.keys():
                count_dict[label_name] = 0
            return count_dict

        sep = util.LABEL_SEPARATOR
        depth = 0
        if not is_prob and label_map is None:
            label_map = dict()
            for label in labels:
                if label not in label_map:
                    label_map[label] = len(label_map)
        if not is_flat:
            for label in label_map.keys():
                hierarchical_labels = label.split(sep)
                depth = max(len(hierarchical_labels), depth)
        label_to_id_maps = []
        id_to_label_maps = []
        for i in range(depth + 1):
            label_to_id_maps.append(dict())
            id_to_label_maps.append(dict())
        for label_name, label_id in label_map.items():
            label_to_id_maps[0][label_name] = label_id
            id_to_label_maps[0][label_id] = label_name
            if not is_flat:
                hierarchical_labels = label_name.split(sep)
                for i in range(1, len(hierarchical_labels) + 1):
                    label = sep.join(hierarchical_labels[:i])
                    if label not in label_to_id_maps[i]:
                        index = len(label_to_id_maps[i])
                        label_to_id_maps[i][label] = index
                        id_to_label_maps[i][index] = label

        confusion_matrix_list = []
        right_category_count_list = []
        predict_category_count_list = []
        standard_category_count_list = []
        for i in range(depth + 1):
            confusion_matrix_list.append(
                _init_confusion_matrix(label_to_id_maps[i]))
            right_category_count_list.append(
                _init_count_dict(label_to_id_maps[i]))
            predict_category_count_list.append(
                _init_count_dict(label_to_id_maps[i]))
            standard_category_count_list.append(
                _init_count_dict(label_to_id_maps[i]))

        line_count = 0

        debug_file = codecs.open("probs.txt", "w", encoding=util.CHARSET)
        for predict in predicts:
            if is_prob:
                prob_np = np.array(predict, dtype=np.float32)
                predict_label_id = prob_np.argmax()
                predict_label_name = id_to_label_maps[0][predict_label_id]
                debug_file.write(json.dumps(prob_np.tolist()))
                debug_file.write("\n")
            else:
                predict_label_name = predict

            standard_label_name = labels[line_count]
            if predict_label_name not in label_to_id_maps[0] or \
                    standard_label_name not in label_to_id_maps[0]:
                line_count += 1
                continue
            confusion_matrix_list[0][standard_label_name][
                predict_label_name] += 1
            standard_category_count_list[0][standard_label_name] += 1
            if (is_prob and prob_np.max() > threshold) or not is_prob:
                predict_category_count_list[0][predict_label_name] += 1
                if standard_label_name == predict_label_name:
                    right_category_count_list[0][predict_label_name] += 1

            standard_hierarchical_labels = standard_label_name.split(sep)
            predict_hierarchical_labels = predict_label_name.split(sep)
            standard_label_list = []
            predict_label_list = []
            i = 0

            if not is_flat:
                while i < len(standard_hierarchical_labels):
                    standard_label_list.append(standard_hierarchical_labels[i])
                    standard_label_name = sep.join(standard_label_list)
                    standard_category_count_list[i + 1][
                        standard_label_name] += 1

                    if i < len(predict_hierarchical_labels):
                        predict_label_list.append(
                            predict_hierarchical_labels[i])
                        predict_label_name = sep.join(predict_label_list)
                        confusion_matrix_list[i + 1][standard_label_name][
                            predict_label_name] += 1
                        if (
                                is_prob and prob_np.max() > threshold) or not is_prob:
                            predict_category_count_list[i + 1][
                                predict_label_name] += 1
                            if predict_label_name == standard_label_name:
                                right_category_count_list[i + 1][
                                    predict_label_name] += 1
                    i += 1

                if (is_prob and prob_np.max() > threshold) or not is_prob:
                    while i < len(predict_hierarchical_labels):
                        predict_label_list.append(
                            predict_hierarchical_labels[i])
                        predict_label_name = sep.join(predict_label_list)
                        predict_category_count_list[i + 1][
                            predict_label_name] += 1
                        i += 1
            line_count += 1
        debug_file.close()
        precision_list = []
        recall_list = []
        fscore_list = []
        precision_dict, recall_dict, fscore_dict = \
            self.calculate_level_performance(
                id_to_label_maps[0], right_category_count_list[0],
                predict_category_count_list[0], standard_category_count_list[0],
                exclude_method="start")

        precision_list.append(precision_dict)
        recall_list.append(recall_dict)
        fscore_list.append(fscore_dict)

        for i in range(1, depth + 1):
            precision_dict, recall_dict, fscore_dict = \
                self.calculate_level_performance(
                    id_to_label_maps[i], right_category_count_list[i],
                    predict_category_count_list[i],
                    standard_category_count_list[i], other_text)
            precision_list.append(precision_dict)
            recall_list.append(recall_dict)
            fscore_list.append(fscore_dict)

        (self.confusion_matrix_list, self.precision_list, self.recall_list,
         self.fscore_list, self.right_list, self.predict_list,
         self.standard_list) = (
            confusion_matrix_list, precision_list, recall_list, fscore_list,
            right_category_count_list, predict_category_count_list,
            standard_category_count_list)
        return (confusion_matrix_list, precision_list, recall_list, fscore_list,
                right_category_count_list, predict_category_count_list,
                standard_category_count_list)

    @staticmethod
    def save_confusion_matrix(file_name, confusion_matrix):
        """Save confusion matrix
        Args:
            file_name: File to save to.
            confusion_matrix: Confusion Matrix.
        Returns:
        """
        with codecs.open(file_name, "w", encoding=util.CHARSET) as cm_file:
            cm_file.write("\t")
            for category_fist in sorted(confusion_matrix.keys()):
                cm_file.write(category_fist + "\t")
            cm_file.write("\n")
            for category_fist in sorted(confusion_matrix.keys()):
                cm_file.write(category_fist + "\t")
                for category_second in sorted(confusion_matrix.keys()):
                    cm_file.write(
                        str(confusion_matrix[category_fist][
                                category_second]) + "\t")
                cm_file.write("\n")

    def save_prf(self, file_name, precision_category, recall_category,
                 fscore_category, right_category, predict_category,
                 standard_category):
        """Save precision, recall, fscore
        Args:
            file_name: File to save to.
            precision_category: Precision dict.
            recall_category: Recall dict.
            fscore_category: Fscore dict.
            right_category: Right dict.
            predict_category: Predict dict.
            standard_category: Standard dict.
        Returns:
        """

        def _format(category):
            """Format evaluation string.
            Args:
                category: Category evaluation to format.
            Returns:
            """
            if category == self.MACRO_AVERAGE:
                return "%s, precision: %f, recall: %f, fscore: %f, " % (
                    category, precision_category[category],
                    recall_category[category], fscore_category[category])
            else:
                return "%s, precision: %f, recall: %f, fscore: %f, " \
                       "right_count: %d, predict_count: %d, " \
                       "standard_count: %d" % (
                           category, precision_category[category],
                           recall_category[category], fscore_category[category],
                           right_category[category], predict_category[category],
                           standard_category[category])

        with codecs.open(file_name, "w", encoding=util.CHARSET) as prf_file:
            prf_file.write(_format(self.MACRO_AVERAGE) + "\n")
            prf_file.write(_format(self.MICRO_AVERAGE) + "\n")
            prf_file.write("\n")
            for category in precision_category:
                if category != self.MICRO_AVERAGE and \
                        category != self.MACRO_AVERAGE:
                    prf_file.write(_format(category) + "\n")

    def save(self):
        """Save the latest evaluation.
        """
        for i, confusion_matrix in enumerate(self.confusion_matrix_list):
            if i == 0:
                eval_name = "all"
            else:
                eval_name = "level_%s" % i
            self.save_confusion_matrix(
                self.eval_dir + "/" + eval_name + "_confusion_matrix",
                confusion_matrix)
            self.save_prf(
                self.eval_dir + "/" + eval_name + "_prf",
                self.precision_list[i], self.recall_list[i],
                self.fscore_list[i], self.right_list[i],
                self.predict_list[i], self.standard_list[i])


def main(_):
    config = Config(config_file=sys.argv[1])
    predictor = Predictor(config)
    predict_probs = []
    standard_labels = []
    logger = util.Logger(config)
    if not os.path.exists(config.eval.eval_dir):
        os.makedirs(config.eval.eval_dir)
    with codecs.open(config.eval.eval_dir + "/predict.txt", "w",
                     encoding=util.CHARSET) as predict_file:
        texts = []
        for line in codecs.open(config.eval.text_file, "r",
                                encoding=util.CHARSET):
            line = line.strip("\n")
            texts.append(line)
        batch_size = config.eval.batch_size
        epochs = math.ceil(len(texts) / batch_size)

        for i in range(epochs):
            predicts = predictor.predict(
                texts[i * batch_size: (i + 1) * batch_size])
            for k in range(len(predicts)):
                predict_result = "Nil\t0"
                predict = predicts[k]
                line = texts[i * batch_size + k]
                if predict is not None:
                    predict_np = np.array(predict[0], dtype=np.float32)
                    predict_label = predictor.data_processor.id_to_label_map[
                        np.argmax(predict_np)]
                    predict_result = "%s\t%f" % (
                        predict_label, np.max(predict_np))
                    predict_probs.append(predict[0])
                    standard_labels.append(line.split("\t")[0])
                predict_file.write(predict_result + "\t" + line + "\n")
    evaluator = Evaluator(config.eval.eval_dir)
    (_, precision_list, recall_list, fscore_list,
     right_list, predict_list, standard_list) = evaluator.evaluate(
        predict_probs, standard_labels, predictor.data_processor.label_map,
        config.eval.threshold)
    logger.warn(
        "Test performance, precision: %f, recall: %f, f1: %f, "
        "right: %d, predict: %d, standard: %d" % (
            precision_list[0][evaluator.MICRO_AVERAGE],
            recall_list[0][evaluator.MICRO_AVERAGE],
            fscore_list[0][evaluator.MICRO_AVERAGE],
            right_list[0][evaluator.MICRO_AVERAGE],
            predict_list[0][evaluator.MICRO_AVERAGE],
            standard_list[0][evaluator.MICRO_AVERAGE]))
    evaluator.save()


if __name__ == '__main__':
    tf.app.run()
