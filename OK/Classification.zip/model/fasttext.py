#!usr/bin/env python
# coding:utf8

# Copyright (c) 2018, Tencent. All rights reserved

# Implement FastText
#   Reference "Bag of Tricks for Efficient Text Classification"
#             https://github.com/facebookresearch/fastText

import tensorflow as tf

from model.embedding_layer import EmbeddingLayer
from model.model_helper import ModelHelper


class FastTextEstimator(tf.estimator.Estimator):
    def __init__(self, data_processor, model_params):
        config = data_processor.config
        embedding_layer = EmbeddingLayer(config)
        model_helper = ModelHelper(config)

        def _model_fn(features, labels, mode, params):
            self._check(params["feature_names"], data_processor)
            input_layer = []
            len_list = []
            for feature_name in params["feature_names"]:
                index = data_processor.dict_names.index(feature_name)
                input_layer.append(embedding_layer.get_vocab_embedding_sparse(
                    feature_name, features["var_len_" + feature_name],
                    len(data_processor.dict_list[index]), params["epoch"],
                    pretrained_embedding_file=
                    data_processor.pretrained_embedding_files[index],
                    dict_map=data_processor.dict_list[index],
                    mode=mode))
                len_list.append(features[feature_name + "_var_real_len"])
                if data_processor.ngram_list[index] > 1:
                    ngram_name = feature_name + "_ngram"
                    index = data_processor.dict_names.index(ngram_name)
                    input_layer.append(
                        embedding_layer.get_vocab_embedding_sparse(
                            ngram_name, features["var_len_" + ngram_name],
                            len(data_processor.dict_list[index]),
                            params["epoch"],
                            mode=mode))
                    len_list.append(features[ngram_name + "_var_real_len"])
            hidden_layer = input_layer[0]
            total_len = len_list[0]
            for i in range(1, len(input_layer)):
                hidden_layer = hidden_layer + input_layer[i]
                total_len = total_len + len_list[i]
            hidden_layer = tf.div(hidden_layer, total_len)
            if mode == tf.estimator.ModeKeys.TRAIN:
                hidden_layer = model_helper.dropout(
                    hidden_layer, config.train.hidden_layer_dropout_keep_prob)
            return model_helper.get_softmax_estimator_spec(
                hidden_layer, mode, labels, params["label_size"],
                params["static_embedding"], data_processor.label_dict_file)

        super(FastTextEstimator, self).__init__(
            model_fn=_model_fn, model_dir=config.model_common.checkpoint_dir,
            config=model_helper.get_run_config(), params=model_params)

    @staticmethod
    def _check(feature_names, data_processor):
        for feature_name in feature_names:
            assert feature_name in data_processor.dict_names
            index = data_processor.dict_names.index(feature_name)
            assert len(data_processor.dict_list[index]) > 0
