# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
from pyspark import SparkContext
from pytoolkit import TDWProvider
from pyspark import SQLContext
from pytoolkit import TDWSQLProvider
from pytoolkit import TDWUtil
import sys
import re

def cutLinePartition(lines):
  import sys
  import math
  import jieba
  import jieba.posseg as pseg
  from jieba.analyse import textrank
  from collections import Counter

  reload(sys)
  sys.setdefaultencoding("utf-8")
  kwSet=set()
  for wd, cnt in kwmapData.value.items():
    jieba.add_word(wd, freq=cnt)
    kwSet.add(wd)

  stopWdSet=set()
  for wd in stopwordSet.value:
    stopWdSet.add(wd)

  def is_Ch(uchar):
    if uchar >= u'\u4e00' and uchar <= u'\u9fa5':
      return True
    return False

  def is_Eng(uchar):
    if uchar == u'\u002e':
      return True
    if uchar >= u'\u0030' and uchar <= u'\u0039':
      return True
    if (uchar >= u'\u0041' and uchar <= u'\u005a') or (uchar >= u'\u0061' and uchar <= u'\u007a'):
      return True
    return False

  def is_ustr(in_str):
    out_str = []
    out_stritem = ''
    preEng = False
    for i in range(len(in_str)):
      if is_Ch(in_str[i]):
        if not preEng:
          out_stritem = out_stritem + in_str[i]
        else:
          if len(out_stritem) > 1:
            out_str.append(out_stritem)
          out_stritem = in_str[i]
        preEng = False
      elif is_Eng(in_str[i]):
        if preEng:
          out_stritem = out_stritem + in_str[i]
        else:
          if len(out_stritem) > 1:
            chwordCut = jieba.cut(out_stritem)
            for cutitem in chwordCut: out_str.append(cutitem)
#              if len(cutitem) > 1:
#                out_str.append(cutitem)
          out_stritem = in_str[i]
        preEng = True
      else:
        if len(out_stritem) > 1:
          if preEng == False:
            chwordCut = jieba.cut(out_stritem)
            for cutitem in chwordCut: out_str.append(cutitem)
#              if len(cutitem) > 1:
#                out_str.append(cutitem)
          else:
            out_str.append(out_stritem)
        out_stritem = ''
        preEng = False
    if len(out_stritem) > 1:
      if preEng == False:
        chwordCut = jieba.cut(out_stritem)
        for cutitem in chwordCut: out_str.append(cutitem)
#          if len(cutitem) > 1:
#            out_str.append(cutitem)
      else:
        out_str.append(out_stritem)
    return out_str

  def cutAndRemoveStop(in_str):
    out_str=is_ustr(in_str.lower())
    return ' '.join([x for x in out_str if x not in stopWdSet])

  errorCnt=0

  for line in lines:
    try:
      nickname, signature, title, content = line[10:14]
      vtitle, description=line[20:22]

      nicknameout=is_ustr(nickname.lower())
      signatureout=is_ustr(signature.lower())
      titleout=is_ustr(title.lower())
      contentout=is_ustr(content.lower())
      
      vtitleout=is_ustr(vtitle.lower())
      descriptionout=is_ustr(description.lower())

      ret = line+[ ' '.join([x for x in nicknameout]),\
                   ' '.join([x for x in signatureout]),\
                   ' '.join([x for x in titleout]),\
                   ' '.join([x for x in contentout]),\
                   ' '.join([x for x in vtitleout]),\
                   ' '.join([x for x in descriptionout]) ]
      yield ret

    except Exception, e:
      errorCnt=errorCnt+1
      if errorCnt<=100:
        print('Exception:'+str(line))
        print('str(Exception):\t'+str(Exception))
        print('str(e):\t\t'+str(e))
        print('repr(e):\t'+str(repr(e)))
        print('e.message:\t'+e.message)
      pass

if __name__ == '__main__':
  reload(sys)
  sys.setdefaultencoding("utf-8")

  print('sys.argv:'+str(sys.argv))
  ds = sys.argv[1]

  username = "tdw_bincai"
  password = "cai1399"
  database = "wxbiz_offline_db"
  sc = SparkContext(appName="jieba word cut")
  tdwrdd = TDWProvider(sc, user=username, passwd=password, db=database)

  sqlContext = SQLContext(sparkContext=sc)
  tdwdf = TDWSQLProvider(sqlContext, user=username, passwd=password, db=database)

  tdwutil = TDWUtil(user=username, passwd=password, dbName=database)

  # loading stop word table
  stopdf = tdwdf.table(tblName="permanent_stop_word", priParts=["p_20170921"])
  stopdf.printSchema()
  stopwordData = [str(ii.stop_word).strip() for ii in stopdf.select('stop_word').collect()]
  stopwordSet = sc.broadcast(set(stopwordData))
  print('stopword cnt: %d' % len(stopwordData))
  for ii in range(0, 10):
    print('some data: ', ii, stopwordData[ii])

  # loading kw
  kwmap={}
  kwdf = tdwdf.table(tblName="permanent_kyk_vedio_keyword_map2")
  for item in kwdf.select(['key','cnt']).rdd.map(lambda r:(r[0],r[1])).collect():
    if item[1]>50 and len(item[0])>1: kwmap[item[0].lower()]=item[1]
  kwmapData = sc.broadcast(kwmap)
  kwmap_size=len(kwmap)
  print('kwmap_size: ', len(kwmap) )

  inTable='tmp_kyk_vid_bizmsg_pub_train_data_lda_train'
  outTable='tmp_kyk_vid_bizmsg_pub_train_data_lda_train_seg'
  data = tdwrdd.table(tblName=inTable).mapPartitions(cutLinePartition)
  tdwrdd.saveToTable(data, tblName=outTable)


