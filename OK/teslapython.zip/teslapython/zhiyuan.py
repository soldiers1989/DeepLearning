# -*- coding: utf-8 -*-
try:
    from pyspark.sql import SparkSession
    from pyspark.conf import SparkConf
    from pytoolkit import TDWSQLProvider, TDWUtil, TDWProvider
except:
    pass
import sys
import random

def init(part_name):
    spark = SparkSession.builder.appName("deal data by zhiyuanxu 20180824").getOrCreate()
    username = "tdw_zhiyuanxu"
    password = "qq123!@#"
    # 上下环境初始化
    sc = spark.sparkContext

    tdw_log_hour = TDWSQLProvider(spark, user=username, passwd=password, db="wxg_weixin_tdbank_hour")
    # 注册表
    data1 = tdw_log_hour.table(tblName='log_15569', priParts=part_name)
    data1.registerTempTable("log_15569")

    data2 = tdw_log_hour.table(tblName='log_15570', priParts=part_name)
    data2.registerTempTable("log_15570")
    return [spark, tdw_log_hour]


def get_train_data(x, y):
    # [(uin, [(vid, is_click, show_timestamp, click_timestamp)])]
    lt = x + y
    out = []
    for val in lt:
        if len(val) == 4:
            is_click = int(val[1])
            if is_click == 1:  # 收集点击的
                out.append((val[0], val[2]))
        elif len(val) == 2:
            out.append(val)
    return out


def get_test_data(x, y):
    # [(uin, [(vid, is_click, show_timestamp, click_timestamp)])]
    lt = x + y
    out = []
    for val in lt:
        if len(val) == 4:
            is_click = int(val[1])
            if is_click == 1:  # 收集点击的
                out.append((val[0], val[2])) #, val[3]
            # else:
            #     out.append((val[0], val[1], val[3]))  # 表示显示时间
        elif len(val) == 2:
            out.append(val)
    return out


if __name__ == '__main__':
    print('start')
    ds = sys.argv[1]
    version = sys.argv[2]

    print("ds:%s, verison:%s" % (ds, version))
    # part_name = "p_%s" % ds
    part_name = ["p_%s%2d" % (ds, i) for i in range(24)]

    [spark, tdw_log_hour] = init(part_name)

    print("读取数据。。。")
    ssql = '''select
           a.uin as uin,
           a.vid as vid,
           if(b.uin is null, 0, 1) as is_click,
           show_timestamp,
           if(click_timestamp is null, 0, click_timestamp) as click_timestamp
        from
        (
            select
                a.uin as uin,
                vid,
                show_timestamp
            from
            (
                select
                    uin_ as uin, 
                    vid_ as vid,
                    timestamp_ as show_timestamp
                from
                (
                    select
                        uin_,
                        vidlist_,
                        timestamp_
                    from log_15569
                    where ds >= %s00 and ds <= %s23 
                )tmp 
                lateral view explode(split(vidlist_,'\;')) vids as vid_
            )a
            JOIN
            (
                select
                    uin,
                    click_uv
                from
                (
                    SELECT
                        uin,
                        count(1) as click_pv,
                        count(DISTINCT vid) as click_uv
                    FROM
                    (    
                        select 
                            uin_ as uin,
                            vid_ as vid,
                            timestamp_ as click_timestamp,
                            PlayTime_ as playtime
                        from log_15570
                        where ds >= %s00 and ds <= %s23
                        and PlayTime_>7000 
                    )tmp group by uin  
                )tmp  where click_uv>=500
               --order by click_uv desc limit 100
            )b on a.uin=b.uin
        )a
        left outer join
        (
            select
                *
            from 
            (
                select 
                    uin_ as uin,
                    vid_ as vid,
                    timestamp_ as click_timestamp,
                    PlayTime_ as playtime,
                    rank() over(partition by uin_ order by timestamp_ desc) as ts_rk
                from log_15570
                where ds >= %s00 and ds <= %s23
                and PlayTime_>7000
            )tmp where ts_rk <= 20
        )b on a.uin=b.uin and a.vid=b.vid 
        where click_timestamp is null or (click_timestamp is not null and click_timestamp>show_timestamp)''' % (
    ds, ds, ds, ds, ds, ds)
    print(ssql)
    uin_vid_df = spark.sql(ssql)  # 获取最终的数据
    print(uin_vid_df.head())
    print("uin_vid_df count: %d" % uin_vid_df.count())

    uin_vid_rdd = uin_vid_df.rdd
    uin_lt = list(set(uin_vid_rdd.map(lambda x: (x["uin"])).collect()))
    test_len = int(len(uin_lt) / 2)
    test_uin_set = set(random.sample(uin_lt, test_len))
    print("test_uin_set count: %d" % len(test_uin_set))
    print(uin_vid_rdd.take(1))

    #[(uin, [(vid, is_click, show_timestamp, click_timestamp)])]
    print("处理数据.....")
    uin_vid_rdd = uin_vid_rdd.map(
        lambda x: (x["uin"], [(x["vid"], x["is_click"], x["show_timestamp"], x["click_timestamp"])]))
    uin_vid_test_rdd = uin_vid_rdd.filter(lambda x: len(x) > 0 and x[0] in test_uin_set)
    uin_vid_train_rdd = uin_vid_rdd.filter(lambda x: len(x) > 0 and x[0]) # not in test_uin_set

    train_data_rdd = uin_vid_train_rdd.reduceByKey(lambda x, y: get_train_data(x, y)).flatMap(lambda x:[(x[0], val[0], val[1]) for val in x[1]]).filter(lambda  x: len(x)>0).map(lambda x: '\t'.join([str(val) for val in x]))
    test_data_rdd = uin_vid_test_rdd.reduceByKey(lambda x, y: get_test_data(x, y)).flatMap(lambda x:[(x[0], val[0], val[1]) for val in x[1]]).filter(lambda  x: len(x)>0).map(lambda x: '\t'.join(str(val) for val in x))

    # 存储hdfs
    train_data = "hdfs://ss-wxg-3-v2/stage/outface/WXG/g_wxg_wxplat_g_wxg_bizmp_sla/zhiyuanxu/smb/GRU4Rec_TensorFlowwk/%s/TrainData/%s"%(version, ds)
    test_data = "hdfs://ss-wxg-3-v2/stage/outface/WXG/g_wxg_wxplat_g_wxg_bizmp_sla/zhiyuanxu/smb/GRU4Rec_TensorFlowwk/%s/TestData/%s"%(version, ds)
    print(train_data)
    print(train_data_rdd.take(1))
    print(test_data)
    print(test_data_rdd.take(1))
    train_data_rdd.saveAsTextFile(train_data)
    test_data_rdd.saveAsTextFile(test_data)