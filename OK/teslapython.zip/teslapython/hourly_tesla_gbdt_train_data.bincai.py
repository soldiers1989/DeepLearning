#coding: utf-8
import sys, os
import numpy as np

from pyspark import SparkContext, SparkConf
from pyspark import SQLContext
from pytoolkit import TDWSQLProvider, TDWUtil, TDWProvider

import hashlib, datetime, time

user_name='tdw_chunzhuang'
password='447642253'
db='wxbiz_offline_db'
pathprefix='hdfs://tl-if-nn-tdw.tencent-distribute.com:54310/stage/outface/WXG/g_wxg_wxplat_wxbiz_online_datamining/bincai/vediogbdt/'

columns = 'class_id_1,class_id_2,genderbucket,agebucket,gradebucket'.split(',')
ctr_columns = 'timelineview_1,timelineclick_1,timelinevv_1,timelineviewv_1,timelinevvv_1,timelineplaytime_1,timelinectr_1'.split(',')
ctr_columns += 'timelineview_3,timelineclick_3,timelinevv_3,timelineviewv_3,timelinevvv_3,timelineplaytime_3,timelinectr_3'.split(',')
ctr_columns += 'timelineview_5,timelineclick_5,timelinevv_5,timelineviewv_5,timelinevvv_5,timelineplaytime_5,timelinectr_5'.split(',')
ctr_columns += 'timelineview_7,timelineclick_7,timelinevv_7,timelineviewv_7,timelinevvv_7,timelineplaytime_7,timelinectr_7'.split(',')
ctr_columns += 'timelineview_14,timelineclick_14,timelinevv_14,timelineviewv_14,timelinevvv_14,timelineplaytime_14,timelinectr_14'.split(',')


###################some common funs
def tdw_obj(sqlContext):
    tdw_offline = TDWSQLProvider(sqlContext, user=user_name, passwd=password, db=db)
    tdw_df = TDWProvider(sqlContext,user = user_name, passwd = password, db = db)
    tdwutil = TDWUtil(user=user_name, passwd=password, dbName=db)
    return tdw_offline, tdw_df, tdwutil

def create_partition(tdwutil, table, partName, name, level):
    try:
        tdwutil.createListPartition(table, partName, str(name), level)
    except:
        print('create table %s partition %s %s exists...' % (table, level, name))

def deal_float(x):
    try:
        x = float(x) + 1e-5
    except:
        x = 0.0 + 1e-5
    return x

def deal_row(x):
    reload(sys)
    sys.setdefaultencoding("utf-8")

    class_id_1 = 'l1_%s' % x['class_id_1']
    class_id_2 = 'l2_%s' % x['class_id_2']

    uin, vid, bizuin, msgid, idx = x['uin'], x['vid'], x['bizuin'], x['msgid'], x['idx']
    none = set(['None', 'none'])
    tags = set(str(x['tag']).replace(',', '').split(';')) | set(str(x['op_tag']).replace(',', '').split(';')) - none

#######################
    uin_tags = {}
    for one in str(x['uin_tags']).replace(',', '').split('|'):
        arr = one.split(':')
        if len(arr) != 2 or arr[0] in none:
            continue
        uin_tags[arr[0]] = float(arr[1])

    uin_categorys = {}
    for one in str(x['uin_categorys']).replace(',', '').split('|'):
        arr = one.split(':')
        if len(arr) != 2 or arr[0] in none:
            continue
        uin_categorys[arr[0]] = float(arr[1])

    kyk_tags = {}
    for one in str(x['kyk_vid_tag']).replace(',', '').split(';'):
        arr = one.split(':')
        if len(arr) != 2 or arr[0] in none:
            continue
        kyk_tags[arr[0]] = float(arr[1])

#######################
    cross_uin_tag_cnt = 0
    cross_uin_tag_weights = 0
    total_uin_tag_weights = 0
    cross_uin_tags = []
    for tag, weight in uin_tags.items():
        total_uin_tag_weights += weight
        if tag in tags:
            cross_uin_tag_cnt += 1
            cross_uin_tag_weights += weight
            cross_uin_tags.append(tag)

    cross_uin_tag_cnt_per1 = 0 if len(tags) == 0 else cross_uin_tag_cnt / float(len(tags))
    cross_uin_tag_cnt_per2 = 0 if (len(uin_tags)) == 0 else cross_uin_tag_cnt / float(len(uin_tags))
    cross_uin_tag_weights_per = 0 if total_uin_tag_weights == 0 else cross_uin_tag_weights / total_uin_tag_weights

#######################
    cross_kyk_tag_cnt = 0
    cross_kyk_tag_weights = 0
    total_kyk_tag_weights = 0
    cross_kyk_tags = []
    for tag, weight in kyk_tags.items():
        total_kyk_tag_weights += weight
        if tag in tags:
            cross_kyk_tag_cnt += 1
            cross_kyk_tag_weights += weight
            cross_kyk_tags.append(tag)

    cross_kyk_tag_cnt_per1 = 0 if len(tags) == 0 else cross_kyk_tag_cnt / float(len(tags))
    cross_kyk_tag_cnt_per2 = 0 if (len(kyk_tags)) == 0 else cross_kyk_tag_cnt / float(len(kyk_tags))
    cross_kyk_tag_weights_per = 0 if total_kyk_tag_weights == 0 else cross_kyk_tag_weights / total_kyk_tag_weights

#######################
    class_id_1_per = uin_categorys.get(class_id_1, 0)
    class_id_2_per = uin_categorys.get(class_id_2, 0)

#######################
    features = [x[col] for col in columns] + \
    [
        cross_uin_tag_cnt, cross_uin_tag_weights, total_uin_tag_weights, cross_uin_tag_cnt_per1, cross_uin_tag_cnt_per2, cross_uin_tag_weights_per,
        cross_kyk_tag_cnt, cross_kyk_tag_weights, total_kyk_tag_weights, cross_kyk_tag_cnt_per1, cross_kyk_tag_cnt_per2, cross_kyk_tag_weights_per,
        class_id_1_per, class_id_2_per
    ] + [x[col] for col in ctr_columns]

    #存为libsvm格式
    l = [str(x['is_click'])]
    for k, col in enumerate(features):
        try:
            v = round(float(col), 5)
            if v != 0:
                l.append(str(k+1)+':'+str(v))
        except:
            pass
    return ' '.join(l)

def run():
    t = datetime.datetime.strptime(ds, "%Y%m%d")
    dateago = t-datetime.timedelta(days = 1)
    dateago = dateago.strftime("%Y%m%d")

    dateago2 = t-datetime.timedelta(days = 2)
    dateago2 = dateago2.strftime("%Y%m%d")

    partName_ago = "p_%s" % dateago
    partName_ago2 = "p_%s" % dateago2
    partName = "p_%s" % ds
    partNameDh = "p_%s" % dh

    tdw_offline, tdw_df, tdwutil = tdw_obj(sqlContext)

    """小时级数据"""
    data = tdw_offline.table(tblName = 'hourly_video_tag_cold_start_mid_data') #所有分区的训练数据都使用, priParts=[partNameDh]

    ctr_data = tdw_offline.table(tblName = 'daily_video_tag_uin_timeline_ctr_data2', priParts=[partName_ago2, partName_ago])
    ctr_data = ctr_data.filter(ctr_data.timelineview_1.isNotNull())
    ctr_data = ctr_data.dropDuplicates(subset = ['uin'])
    ctr_data = ctr_data.withColumnRenamed('uin', 'uin2')

    data = data.join(ctr_data, data.uin == ctr_data.uin2, 'left')
    data = data.map(lambda x: deal_row(x))

    print('hourly data cnt:', data.count())

    """天级别的数据合并"""
    cnt = 0
    try:
        data2 = sc.textFile(path + 'lr/online/' + 'tesla_train_lr_data_v3_%s' % dateago)
        cnt = data2.count()
    except:
        pass
    try:
        if cnt < 100:
            print('use data day ago...') #如果当天的数据还没有生成，用前一天的数据
            data2 = sc.textFile(path + 'lr/online/' + 'tesla_train_lr_data_v3_%s' % dateago2)
        data = data.union(data2)

        print('daily data cnt:', cnt)
    except:
        pass

    print('merge data cnt:', data.count())

    data.repartition(500).saveAsTextFile(path + 'lr/online/' + 'tesla_train_lr_data_v3_%s' % dh)

if __name__ == '__main__':
    """
    !!!! 此代码适用于 pyspark 1.6 环境 !!!!
    """
    reload(sys)
    sys.setdefaultencoding("utf-8")
    global sc
    global sqlContext
    global path
    global dh
    global ds

    sc = SparkContext(appName="daily origin mp training data")
    sqlContext = SQLContext(sparkContext=sc)

    path = check_hdfs_path(sc) + 'video_tag/'

    dh = str(sys.argv[1].strip())
    ds = dh[:8]

    run()