# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
from pyspark import SparkContext
from pytoolkit import TDWProvider
from pyspark import SQLContext
from pytoolkit import TDWSQLProvider
from pytoolkit import TDWUtil
import sys
import re

def cutLinePartition(lines):
  import sys
  import math
  import jieba
  import jieba.posseg as pseg
  from jieba.analyse import textrank
  from collections import Counter

  reload(sys)
  sys.setdefaultencoding("utf-8")
  kwmap = kwmapData.value
  for wd, cnt in kwmap.items():
    jieba.add_word(wd)

  def is_Ch(uchar):
    if uchar >= u'\u4e00' and uchar <= u'\u9fa5':
      return True
    return False

  def is_Eng(uchar):
    if uchar == u'\u002e':
      return True
    if uchar >= u'\u0030' and uchar <= u'\u0039':
      return True
    if (uchar >= u'\u0041' and uchar <= u'\u005a') or (uchar >= u'\u0061' and uchar <= u'\u007a'):
      return True
    return False

  def is_ustr(in_str):
    out_str = []
    out_stritem = ''
    preEng = False
    for i in range(len(in_str)):
      if is_Ch(in_str[i]):
        if not preEng:
          out_stritem = out_stritem + in_str[i]
        else:
          if len(out_stritem) > 1:
            out_str.append(out_stritem)
          out_stritem = in_str[i]
        preEng = False
      elif is_Eng(in_str[i]):
        if preEng:
          out_stritem = out_stritem + in_str[i]
        else:
          if len(out_stritem) > 1:
            chwordCut = jieba.cut(out_stritem)
            for cutitem in chwordCut:
              if len(cutitem) > 1:
                out_str.append(cutitem)
          out_stritem = in_str[i]
        preEng = True
      else:
        if len(out_stritem) > 1:
          if preEng == False:
            chwordCut = jieba.cut(out_stritem)
            for cutitem in chwordCut:
              if len(cutitem) > 1:
                out_str.append(cutitem)
          else:
            out_str.append(out_stritem)
        out_stritem = ''
        preEng = False
    if len(out_stritem) > 1:
      if preEng == False:
        chwordCut = jieba.cut(out_stritem)
        for cutitem in chwordCut:
          if len(cutitem) > 1:
            out_str.append(cutitem)
      else:
        out_str.append(out_stritem)
    return out_str

  def cutAndRemoveStop(in_str):
    out_str=is_ustr(in_str.lower())
    return ' '.join([x for x in out_str if x not in stopWdSet])

  errorCnt=0

  for line in lines:
    vid, c1, c2, title, tag = line[0:5]
    
    titlecut=[str(kwmap.get(x, 0)) for x in is_ustr(title.lower())]
    c1id=str(kwmap.get(c1, 0))
    c2id=str(kwmap.get(c2, 0))
    tagid=' '.join([str(kwmap.get(x, 0)) for x in tag.split(' ')])
    yield line+['|'.join([vid, title, c1id, c2id, ' '.join(titlecut), str(len(titlecut)), tagid])]

if __name__ == '__main__':
  reload(sys)
  sys.setdefaultencoding("utf-8")

  username = "tdw_bincai"
  password = "cai1399"
  database = "wxbiz_offline_db"
  sc = SparkContext(appName="jieba word cut")
  tdwrdd = TDWProvider(sc, user=username, passwd=password, db=database)

  sqlContext = SQLContext(sparkContext=sc)
  tdwdf = TDWSQLProvider(sqlContext, user=username, passwd=password, db=database)

  tdwutil = TDWUtil(user=username, passwd=password, dbName=database)

  # loading kw
  kwmap={}
  kwdf = tdwdf.table(tblName="tmp_fasttext_vedio")
  for item in kwdf.select(['wid','ww']).rdd.map(lambda r:(r[0],r[1])).collect():
    kwmap[item[1]]=item[0]
  kwmapData = sc.broadcast(kwmap)
  kwmap_size=len(kwmap)
  print('kwmap_size: ', len(kwmap) )
  
  inTable = "tmp_daily_mid_wxsearch_kyk_video_log_share212_vid_profile_sample"
  #inTable = "tmp_daily_mid_wxsearch_kyk_video_log_share212_vid_profile"
  outTable = "tmp_daily_mid_wxsearch_kyk_video_log_share212_vid_profile_processed"

  data = tdwrdd.table(tblName=inTable).mapPartitions(cutLinePartition)
  tdwrdd.saveToTable(data, tblName=outTable)



#  # loading idf
#  idfmap={}
#  idfdf = tdwdf.table(tblName="tmp_train_data_vedio_idf")
#  for item in idfdf.select(['token','cnt']).rdd.map(lambda r:(r[0],r[1])).collect():
#    idfmap[item[0]]=item[1]
#  idfmapData = sc.broadcast(idfmap)
#  idfmap_size=len(idfmap)
#  print('idfmap_size: %d' % idfmap_size)
#
#  # loading stop word table
#  stopdf = tdwdf.table(tblName="permanent_stop_word", priParts=["p_20170921"])
#  stopdf.printSchema()
#  stopwordData = [str(ii.stop_word).strip() for ii in stopdf.select('stop_word').collect()]
#  stopwordSet = sc.broadcast(set(stopwordData))
#  print('stopword cnt: %d' % len(stopwordData))
#  for ii in range(0, 10):
#    print('some data: ', ii, stopwordData[ii])

#drop table tmp_train_data_vedio_classification2_cut2_result4;
#CREATE TABLE tmp_train_data_vedio_classification2_cut2_result4(
#    ds BIGINT,
#    bizuin BIGINT,
#    msgid BIGINT,
#    idx BIGINT,
#    vid STRING,
#    vtitle STRING,
#    description STRING,
#    pic_url STRING,
#    class_id_1 BIGINT,
#    class_id_1_name STRING,
#    class_id_2 BIGINT,
#    class_id_2_name STRING,
#    class_1_2 INT,
#    tag STRING,
#    title STRING,
#    content STRING,
#    posttime BIGINT,
#    nickname STRING,
#    signature STRING,
#    vtitlepossegs STRING,
#    titlepossegs STRING,
#    txtrank STRING,
#    tfidf STRING,
#    seelctkw STRING,
#    checkresult STRING,
#    ruleresult STRING,
#    top5kw STRING,
#    lenseelctkw STRING,
#    matched STRING,
#    matched1 STRING,
#    lencheckresult STRING,
#    lentop5kw STRING,
#    lentop5kwinterset STRING
#)
#STORED AS ORCFILE COMPRESS;

