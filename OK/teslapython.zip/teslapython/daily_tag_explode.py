# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
from pyspark import SparkContext
from pytoolkit import TDWProvider
from pyspark import SQLContext
from pytoolkit import TDWSQLProvider
from pytoolkit import TDWUtil
import sys
import re

def explodeTags(lines):
  import sys
  import math

  reload(sys)
  sys.setdefaultencoding("utf-8")

  for line in lines:
    try:
      cate, tags=line[0:2]
      rlist=[cate]+[x for x in tags.split(';') if x!='None' and len(x)>0]

      for ii in range(len(rlist)):
        for jj in range(len(rlist)):
          if(ii!=jj):
            yield(('0',rlist[ii],rlist[jj]))

          if(ii<jj):
            yield(('1',rlist[ii],rlist[jj]))

    except Exception, e:
      errorCnt=errorCnt+1
      if errorCnt<=100:
        print('Exception:'+str(line))
        print('str(Exception):\t'+str(Exception))
        print('str(e):\t\t'+str(e))
        print('repr(e):\t'+str(repr(e)))
        print('e.message:\t'+e.message)
      pass

if __name__ == '__main__':
  reload(sys)
  sys.setdefaultencoding("utf-8")

  print('sys.argv:'+str(sys.argv))
  ds = sys.argv[1]

  username = "tdw_bincai"
  password = "cai1399"
  database = "wxbiz_offline_db"
  sc = SparkContext(appName="TAG EXPLODE")
  tdwrdd = TDWProvider(sc, user=username, passwd=password, db=database)

  sqlContext = SQLContext(sparkContext=sc)
  tdwdf = TDWSQLProvider(sqlContext, user=username, passwd=password, db=database)

  tdwutil = TDWUtil(user=username, passwd=password, dbName=database)

  inTable='daily_mid_wxsearch_recommend_video_info_accumulate_v2'
  outTable='daily_mid_wxsearch_recommend_video_tag_explode'
  data = tdwrdd.table(tblName=inTable).mapPartitions(explodeTags)
  tdwrdd.saveToTable(data, tblName=outTable)
