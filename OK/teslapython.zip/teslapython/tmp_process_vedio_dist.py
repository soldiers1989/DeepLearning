# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
from pyspark import SparkContext
from pytoolkit import TDWProvider
from pyspark import SQLContext
from pytoolkit import TDWSQLProvider
from pytoolkit import TDWUtil
import sys
import re

# tmp_vid_vector_idx    tmp_vid_vector_left
def mapDist(lines):
  import numpy as np
  from numpy import dot
  from numpy.linalg import norm
  
  reload(sys)
  sys.setdefaultencoding("utf-8")
  
  itemMap=kwmapData.value
  comitems=[]
  for key, value in itemMap.items():
    emb=value[0]
    emb=np.array([float(x) for x in emb.strip(' ').split(' ')])
    tag=value[1]
    comitems.append((key, emb, tag))    
    
  for line in lines:
    vid, emb, tag=line[0:3]
    emb=np.array([float(x) for x in emb.strip(' ').split(' ')])
    
    for vidrg, embrg, tagrg in comitems:  
      if vid==vidrg: continue 
      dist = np.linalg.norm(embrg-emb)
      cos_sim = dot(embrg, emb)/(norm(embrg)*norm(emb))
    
      yield [vid, tag, vidrg, tagrg, str(dist), str(cos_sim)]

if __name__ == '__main__':
  reload(sys)
  sys.setdefaultencoding("utf-8")
  
  username = "tdw_bincai"
  password = "cai1399"
  database = "wxbiz_offline_db"
  sc = SparkContext(appName="jieba word cut")
  tdwrdd = TDWProvider(sc, user=username, passwd=password, db=database)
  
  sqlContext = SQLContext(sparkContext=sc)
  tdwdf = TDWSQLProvider(sqlContext, user=username, passwd=password, db=database)
  tdwutil = TDWUtil(user=username, passwd=password, dbName=database)

  # loading dest vedio
  kwmap={}
  kwdf = tdwdf.table(tblName="tmp_vid_vector_left")
  for item in kwdf.select(['vid', 'vector', 'cattag' ]).rdd.map(lambda r:(r[0],(r[1], r[2]))).collect():
    kwmap[item[0]]=item[1]
    print('%s %s'%(item[0], str(item[1])))
  kwmapData = sc.broadcast(kwmap)
  kwmap_size=len(kwmap)
  print('kwmap_size: ', len(kwmap) )

  inTable='tmp_vid_vector_idx'
  #inTable='tmp_vid_vector_idx_sample'
  outTable='tmp_vid_vector_dis'
  data = tdwrdd.table(tblName=inTable).mapPartitions(mapDist)
  tdwrdd.saveToTable(data, tblName=outTable)


#  dirPath='hdfs://tl-if-nn-tdw.tencent-distribute.com:54310/stage/outface/WXG/g_wxg_wxplat_wxbiz_online_datamining/bincai/export/20180436/'
#  textFiles = sc.textFile(dirPath)
#  data=textFiles.mapPartitions(mapToTable)
#  outTable='tmp_vid_vector'
#  tdwrdd.saveToTable(data, tblName=outTable)


#  inTable='daily_vid_bizmsg_pub'
#  outTable='daily_vid_bizmsg_pub_seg'
#  try:
#    tdwutil.createListPartition(outTable, "p_"+ds, ds)
#  except:
#    pass
#  data = tdwrdd.table(tblName=inTable, priParts=["p_"+ds]).mapPartitions(cutLinePartition)
#  tdwrdd.saveToTable(data, tblName=outTable, priPart="p_"+ds)
#
#  # loading word map
#  kwmap={}
#  kwdf = tdwdf.table(tblName="tmp_kyk_vid_bizmsg_lda_token_stat")
#  for item in kwdf.select(['token','rk']).rdd.map(lambda r:(r[0],r[1])).collect():
#    if item[1]<30000: kwmap[item[0].lower()]=item[1]
#  kwmapData = sc.broadcast(kwmap)
#  kwmap_size=len(kwmap)
#  print('kwmap_size: ', len(kwmap) )
#
#  data = tdwrdd.table(tblName=outTable, priParts=["p_"+ds]).mapPartitions(mapToLdaFormat)
#  #data = tdwrdd.table(tblName='tmp_daily_vid_bizmsg_pub_seg').mapPartitions(mapToLdaFormat)
#  outputpath='hdfs://tl-if-nn-tdw.tencent-distribute.com:54310/stage/outface/WXG/g_wxg_wxplat_wxbiz_online_datamining/bincai/vediolda/'+ds+'/'
#  print(outputpath)
#  data.saveAsTextFile(outputpath)

#CREATE TABLE tmp_vid_vector(
#    vid STRING,
#    vector STRING,
#    cattag STRING
#)
#STORED AS ORCFILE COMPRESS;
#
#CREATE TABLE tmp_vid_vector_dis(
#    vid1 STRING,
#    cattag1 STRING,
#    vid2 STRING,
#    cattag2 STRING,
#    euldis DOUBLE,
#    cosdis DOUBLE
#)
#STORED AS ORCFILE COMPRESS;



