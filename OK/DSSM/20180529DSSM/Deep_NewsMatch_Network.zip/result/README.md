## 相关结果及说明

相关结果主要从两点说明：1） 相关性模型本身； 2）在实际产品上的应用；
### 相关性模型训练结果
1. 模型体验地址：  http://tesla.oa.com/teslaml/admin/platform.htm?projectId=10011&flowId=13648#
2. 模型在测试集上结果如下：
<img src="http://git.code.oa.com/AI_algorithm/Deep_NewsMatch_Network/raw/ef055b11a9225287004c799c0300613f20d87abb/img/telas.png" width="30%" height="30%">
其中， test acc 是模型在测试集上的准确率， 计算方式为的是一个batch内， 正例和news的相似度得分，大于负例的比例；
3. 该指标说明，匹配候选集越大，召回的准确率越高； 在候选集充足的情况下，相关性匹配的准确率可达96%以上；

### 在新闻客户端底层页相关问答项目的应用情况
1. news_related_qa.xls 
该表为基于该框架计算的新闻相关的top3的问答结果， 该结果采用语义相似度的得分排序，**同时辅助于相关过滤策略**； 
人工评估准确率接近**100%**，召回率71%左右（产品设计要求，准确率第一位），日均展现pv 1.7亿；

2. dnn&word2vec_review_result.xlsx
该表为，未加任何规则性过滤策略的相同前提下， 训练的语义向量和word2vec的语义向量，计算新闻相关问答的top1对比数据；
其中，相关新闻准确率比word2vec高**12.5%（0.91 vs 0.8）** 
