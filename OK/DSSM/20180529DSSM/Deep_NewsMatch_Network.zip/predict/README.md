采用FC层的输出作为文本的语义向量，该模块就是根据输入的文本和训练的模型，计算其语义向量；
### 文件说明

- **predict.py** ： 预测程序， 根据输入的文本 & 模型，计算改文本的语义向量
- line_predict.py， utils.py 辅助程序
- input_sample 数据输入样例

### 预估流程
#### predict模块的流程如下
<img src="http://git.code.oa.com/AI_algorithm/Deep_NewsMatch_Network/raw/80f824b929930b787e02d58e64e6e9d3350c2723/img/predict.png" width="45%" height="45%">
#### 执行步骤说明
1. reload 模型的各层参数；
2. 将输入id化；
3. 依次通过embedding层，CNN&Bow层、FC层、将FC层的输出，作为输入的语义向量输出即可；
### 使用说明
1.  选定好train 模块训练的模型, 和id化生成的词典：term.id ;
2.  准备好需要计算向量的数据， 如input_samle;
3.  python 需预先安装jieba分词插件；
4.  执行predict.py 即可;

>cat input_file | predict.py model_prefix

### 输入数据格式
>刘德华电影怎么样 \t 刘德华 电影
看不起印度？原来印度人比中国人幸福多了 \t 印度 中国人 幸福；

两列，用\t切分，第一列是title， 第二列是文章提取的tag list
