#!/usr/bin/env python
# vim: set fileencoding=utf-8 :
# @author: bingfeng@tencent.com 
# @date: 2017/06/01 

import numpy
import jieba

class LinePredict(object):
    def __init__(self, data, term_dict = {}):
        _data = data.split("\t")
        title = _data[0]
        tags  = _data[1]
            
        title_ids_tmp = jieba.cut(title)
        tag_ids_tmp   = tags.split(" ")
        self.title_ids = self.to_list(title_ids_tmp, term_dict)
        self.tag_ids   = self.to_list(tag_ids_tmp, term_dict, False)
        self.title = title

    def to_list (self, terms, term_dict, need_encode = True):
        res = []
        for t in terms:
            if (need_encode):
                t = t.encode("utf8")
            if (not term_dict.has_key(t)):
                continue
            t = term_dict[t]
            res.append(t)
        return res

    def get_triplet(self, n_triplets=1, max_line_size = 128):
        title_val = []
        t_title = []
        t_title.append(self.title)

        y = 0
        title_list = self.title_ids 
        for t in title_list:
            t = t.strip()
            if not t.isdigit():
                continue    
            y = y + 1
            title_val.append(int(t)+1)
            if (y >= max_line_size - 1):
                break
        k = 25-len(title_val)
        if(k>0):
            title_val+=[0]*k
        else:
            title_val=title_val[0:25]
        
        tag_idx = []
        tag_val = []
        tag_list = self.tag_ids 
        y = 0
        for w in tag_list:
            w = w.strip()
            if not w.isdigit():
                continue
            ids_tmp = []
            ids_tmp.append(0)
            ids_tmp.append(y)
            y = y + 1
            tag_idx.append(ids_tmp)
            tag_val.append(int(w))
            if (y >=max_line_size-1):
                break     
        title_array = numpy.array(title_val)
        title_val = title_array.reshape((n_triplets,25))
        return title_val, tag_idx, tag_val, t_title

