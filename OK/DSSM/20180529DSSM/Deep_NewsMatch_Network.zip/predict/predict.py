#!/usr/bin/env python
# vim: set fileencoding=utf-8 :
# @author: bingfengli@tencent.com
# @date: 2017/06/01

import utils
import os
import sys
import math
from line_predict import LinePredict
import tensorflow as tf
import numpy as np

vocabulary_size = 610753
emb_size = 150
batch_size  = 1
input_max_size = 10

kernel_sizes = [3, 4, 5]
n_filters = 50
sentence_len = 25

def main():
    global model
    ## define shape
    sparse_shape    = np.array([batch_size, input_max_size], dtype=np.int32)
    
    ## define embeddings
    embeddings = utils.add_embedding(vocabulary_size, emb_size,   emb_name="embeddings") 
    embedding_zero = tf.constant(0.0, shape=[1, emb_size], dtype=tf.float32)
    embedding_with_zero = tf.concat([embedding_zero, embeddings],0)

    ##input ids
    input_title_ids     = tf.placeholder(shape=[batch_size, sentence_len], dtype='int32')
    ##input sparse ids
    input_tag_ids       = tf.sparse_placeholder(tf.int32)

    ##----------------------------embedding layer
    ## title embeding
    title_embedding     = tf.nn.embedding_lookup(embedding_with_zero, input_title_ids)
    ## tag embeding 
    tag_embedding       = tf.nn.embedding_lookup_sparse(embeddings, input_tag_ids, None, combiner='mean')

    ##----------------------------CNN layer
    ##Init CNN Filters
    cnn_w0 = tf.Variable(tf.random_uniform([kernel_sizes[0], emb_size, 1, n_filters], -0.2,0.2), dtype='float32', name="cnn_w0")
    cnn_w1 = tf.Variable(tf.random_uniform([kernel_sizes[1], emb_size, 1, n_filters], -0.2,0.2), dtype='float32', name="cnn_w1")
    cnn_w2 = tf.Variable(tf.random_uniform([kernel_sizes[2], emb_size, 1, n_filters], -0.2,0.2), dtype='float32', name="cnn_w2")

    cnn_b0 = tf.Variable(tf.constant(0.00001, shape=[n_filters]), name = "cnn_b0")
    cnn_b1 = tf.Variable(tf.constant(0.00001, shape=[n_filters]), name = "cnn_b1")
    cnn_b2 = tf.Variable(tf.constant(0.00001, shape=[n_filters]), name = "cnn_b2")

    #impl cnn
    title_3d    = tf.expand_dims(title_embedding, -1)
    title_cnn   = utils.get_cnn_feature(cnn_w0, cnn_w1, cnn_w2, cnn_b0, cnn_b1, cnn_b2, title_3d, sentence_len)
    title_cnn_bow_merger = title_cnn + tag_embedding * 0.4
    
    ## ----------------------------------fc layer 
    fc_w0, fc_b0 = utils.create_w_b(emb_size, emb_size, w_name="fc_w0", b_name="fc_b0")
    fc_w1, fc_b1 = utils.create_w_b(emb_size, emb_size, w_name="fc_w1", b_name="fc_b1")

    title_z0 = utils.calculate_y(title_cnn_bow_merger, fc_w0, fc_b0, 1.0)
    title_z1 = utils.calculate_y(title_z0, fc_w1, fc_b1, 1.0)
    
    ## cal losss    
    title_z1_n = tf.nn.l2_normalize(title_z1, 1)

    ## loooooood param from saved model 
    var_to_load = [embeddings, cnn_w0, cnn_w1, cnn_w2, cnn_b0, cnn_b1, cnn_b2, fc_w1, fc_b1, fc_w0, fc_b0]
    saver = tf.train.Saver(var_to_load)
    term_dict = utils.get_term_id_dict("./data/", "term.dict")

    with tf.Session() as session:    
        saver.restore(session, model)
        ## input
        for _input in sys.stdin:
            _input = _input.strip()
            if (not _input):
                continue
            line_predict = LinePredict(_input, term_dict)
            title_ids, tag_ids, tag_val, title = line_predict.get_triplet(n_triplets=1)
            if len(tag_ids) < 1 or len(tag_val) < 1 or len(title) < 1:
                continue
            feed_dict = {input_tag_ids:(tag_ids, tag_val, sparse_shape), input_title_ids:title_ids } 
            
            ## get title & tag merger vec off FC layer
            _z_out = session.run(title_z1_n, feed_dict=feed_dict) 
            utils.output_res(_z_out, title)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print "usage: cat input_file | python " + sys.argv[0] + "model_prefix"
        sys.exit(1)
    
    model = sys.argv[1]
    main()

