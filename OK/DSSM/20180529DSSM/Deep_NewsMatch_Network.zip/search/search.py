#!/usr/bin/env python
# vim: set fileencoding=utf-8 :
# @author: bingfengli@tencent.com
# @date: 2017/06/01

from annoy import AnnoyIndex
import sys

def read_index_dict():
    global index
    dict_id = {}
    voc = index + ".voc"
    inf = open(voc, "r")
    line = inf.readline()
    while line:
        line = line.strip()
        if not line:
            break
        id_tmp,query = line.split("\t")
        dict_id[id_tmp] = query
        line = inf.readline()
    inf.close()
    return dict_id

def get_vec(vec, vec_size):
    vec_ =  vec.split(" ")
    if (len(vec_) != vec_size):
        print "input file vec error"
        return

    vec_res = []
    for v in vec_:
        v = float(v)
        vec_res.append(v)
    return vec_res

def get_list(title):
    res = []
    for t in title:
        if (len(t) < 2):
            continue
        res.append(t)
    return res

def search(u, dict_id, vec_size):
    num = 200
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        line_ = line.split("\t", 1)
        if (len(line_) < 2):
            continue
        cms_id = line_[0]
        vec = get_vec(line_[1], vec_size)
        if not vec:
            continue
    
        res = u.get_nns_by_vector(vec, int(num), int(num) * 10, True) # will find the 1000 nearest neighbors
        id_ = res[0]
        score_ = res[1]
        if (len(id_) < 2):
            continue
    
        res = cms_id + "\t"
        index = 0
        for id_index in id_:
            id_tmp = dict_id[str(id_index)]
            score = score_[index]
            res = res +  id_tmp + "#" + str("%.3f"%score) + "\t"
            index = index + 1
        print res.strip()

def main():
    global index
    vec_size = 128
    u = AnnoyIndex(vec_size)
    u.load(index) # super fast, will just mmap the file
    dict_id = read_index_dict()
    search(u, dict_id, vec_size)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print "usage: cat input | python " + sys.argv[0] + "index_prefix"
        sys.exit(1)

    index = sys.argv[1]
    main()

