### 模块说明
该模块是查询模块，predict模块计算出新闻的语义向量以后， 可采用该模块建立索引，便于快速的相似查询；
建立索引&查询采用开源工具 annoy，详见： https://github.com/spotify/annoy

### 文件说明

- **build.py**：根据文本的语义向量，建立annoy索引
- **search.py**:  查询annoy索引，获取语义相似度最高的TopN的候选
- input_sample：数据输入样例
