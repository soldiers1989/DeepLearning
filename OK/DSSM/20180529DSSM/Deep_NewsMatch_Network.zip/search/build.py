#!/usr/bin/env python
# vim: set fileencoding=utf-8 :
# @author: bingfengli@tencent.com
# @date: 2017/06/01

import sys
from annoy import AnnoyIndex

def get_vec(vec):
    global vec_size
    vec_ =  vec.split(" ")
    if (len(vec_) != vec_size):
        print "input file vec error"
        return

    vec_res = []
    for v in vec_:
        v = float(v)
        vec_res.append(v)
    return vec_res

def read_index():
    global input_file
    global vec_size
    t = AnnoyIndex(vec_size)  # Length of item vector that will be indexed
    index = 0
    dict_id = {}
    inf = open(input_file, "r")
    line= inf.readline()
    while line:
        line = line.strip()
        if not line:
            break
        line_ = line.split("\t", 1)
        if (len(line_) < 2):
            line = inf.readline()
            continue
        cms_id = line_[0]
        id = index
        dict_id[id] = cms_id 
        vec = get_vec(line_[1])
        if (not vec):
            print "input file error"
            exit(0)
        t.add_item(id, vec)
        line = inf.readline()
        index = index + 1
    inf.close()
    return t, dict_id

def build_and_save(tree, dict_id):
    global output_file
    tree.build(10) # 10 trees
    print "save tree to " + output_file
    print "save tree.voc to " + output_file + ".voc"
    tree.save(output_file)
    
    voc_file = output_file + ".voc"
    ouf = open(voc_file, "w")
    for k,v in dict_id.items():
        ouf.write(str(k) + "\t" + v + "\n")
    ouf.close()
    return 0    

def main():
    tree, dict_id = read_index()
    build_and_save(tree, dict_id)


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print "usage: | python " + sys.argv[0] + "input_file output_prefix vector_size"
        sys.exit(1)
        
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    try:
        vec_size = int(sys.argv[3])
    except:
        print "vector size must int"
        sys.exit(1)
    main()

