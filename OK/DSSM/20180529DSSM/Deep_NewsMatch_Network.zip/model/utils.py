#!/usr/bin/env python
# vim: set fileencoding=utf-8 :
# @author: bingfengli@tencent.com 
# @date: 2017/06/01 
import numpy as np
import tensorflow as tf
import math

def calculate_y (x, w, b, keep_prob=1.0):
    y = tf.matmul(x, w) + b 
    y = tf.nn.dropout(y, keep_prob)
    return tf.nn.softsign(y)


def create_w_b(in_size, out_size, w_name="w", b_name="b", fc_type=tf.float32):
    if (in_size < 1 or out_size < 1):
        return "layer size ERROR"

    left  = - math.sqrt(6) / math.sqrt(in_size + out_size)
    right =   math.sqrt(6) / math.sqrt(in_size + out_size)

    w = tf.Variable(tf.random_uniform([in_size, out_size], left, right), dtype=fc_type, name=w_name)
    b = tf.Variable(tf.zeros([out_size]), dtype=fc_type, name=b_name)
    return w,b 

def add_fc_layer(x, in_size, out_size, w_name="w", b_name="b", fc_type=tf.float32, keep_prob=1.0):
    if (in_size < 1 or out_size < 1):
        return "layer size ERROR"

    left  = - math.sqrt(6) / math.sqrt(in_size + out_size)
    right =   math.sqrt(6) / math.sqrt(in_size + out_size)

    w = tf.Variable(tf.random_uniform([in_size, out_size], left, right), dtype=fc_type, name=w_name)
    b = tf.Variable(tf.zeros([out_size]), dtype=fc_type, name=b_name)

    y = tf.matmul(x, w) + b 
    y = tf.nn.dropout(y, keep_prob)
    return tf.nn.relu(y)


def add_embedding(in_size, out_size, emb_type=tf.float32, emb_name="emb"):
    if (in_size < 1 or out_size < 1):
        return "layer size ERROR"

    left  = - math.sqrt(6) / math.sqrt(in_size + out_size)
    right =   math.sqrt(6) / math.sqrt(in_size + out_size)

    return tf.Variable(tf.random_uniform([in_size, out_size], left, right), dtype=emb_type, name=emb_name)


def compute_triplet_loss(title_feature, pos_feature, neg_feature, margin="0.1"):
    sim_pos = tf.reduce_sum(tf.multiply(title_feature, pos_feature), 1)
    sim_neg = tf.reduce_sum(tf.multiply(title_feature, neg_feature), 1)
    loss = tf.maximum(0., sim_neg - sim_pos + margin)
    sim_loss = 1 - sim_pos
    return tf.reduce_mean(loss)


def get_acc(title_z1_out, pos_z1_out, neg_z1_out, margin):
    sim_pos = np.sum(np.multiply(title_z1_out, pos_z1_out), 1)
    sim_neg = np.sum(np.multiply(title_z1_out, neg_z1_out), 1)
    pos_sub_neg = sim_pos - sim_neg - margin
    total_num = title_z1_out.shape[0]
    acc_num = 0 
    for i in range(total_num):
        diff_sim = pos_sub_neg[i]
        if (diff_sim > 0): 
            acc_num = acc_num + 1 
    acc = acc_num * 1.0 / total_num
    return acc

def get_cnn_feature(f1, f2, f3, b1, b2, b3, title, sentence_len):
    #Convolutions
    C1_title = tf.add(tf.nn.conv2d(title, f1, [1,1,1,1], padding='VALID'), b1)
    C2_title = tf.add(tf.nn.conv2d(title, f2, [1,1,1,1], padding='VALID'), b2)
    C3_title = tf.add(tf.nn.conv2d(title, f3, [1,1,1,1], padding='VALID'), b3)
    C1_title = tf.nn.relu(C1_title)
    C2_title = tf.nn.relu(C2_title)
    C3_title = tf.nn.relu(C3_title)

    ##title Max pooling
    maxC1_title = tf.nn.max_pool(C1_title, [1, sentence_len-3+1,1,1] , [1,1,1,1], padding='VALID')
    maxC1_title = tf.squeeze(maxC1_title, [1, 2]) 
    maxC2_title = tf.nn.max_pool(C2_title, [1, sentence_len-4+1,1,1] , [1,1,1,1], padding='VALID')
    maxC2_title = tf.squeeze(maxC2_title, [1,2])
    maxC3_title = tf.nn.max_pool(C3_title, [1, sentence_len-5+1,1,1] , [1,1,1,1], padding='VALID')
    maxC3_title = tf.squeeze(maxC3_title, [1,2])

    #title Concatenating pooled features
    mergered = tf.concat([maxC1_title, maxC2_title, maxC3_title], 1)
    return mergered

def create_cnn_param(kernel_sizes, edim, n_filters):
    F1  = tf.Variable(tf.random_uniform([kernel_sizes[0], edim, 1, n_filters], -0.2, 0.2),dtype='float32')
    F2  = tf.Variable(tf.random_uniform([kernel_sizes[1], edim, 1, n_filters], -0.2, 0.2),dtype='float32')
    F3  = tf.Variable(tf.random_uniform([kernel_sizes[2], edim, 1, n_filters], -0.2, 0.2),dtype='float32')
    FB1 = tf.Variable(tf.constant(0.00001, shape=[n_filters]))
    FB2 = tf.Variable(tf.constant(0.00001, shape=[n_filters]))
    FB3 = tf.Variable(tf.constant(0.00001, shape=[n_filters]))
    return F1, F2, F3, FB1, FB2, FB3

def load_data(data_dir="../data/", file_name="to_train.lst"):
    file=data_dir + file_name
    try:
        inf = open(file, "r")
        
    except:
        print "not file excepttion input file not find"
        return 

    line  = inf.readline()
    res = []
    while line:
        line = line.strip()
        if not line:
            break
        line_ = line.split(";")
        if (len(line_) < 3): 
            line = inf.readline()
            continue
        title = line_[0].strip()
        pos   = line_[1].strip()
        neg   = line_[2].strip()
        if not title or not pos or not neg:
            line = inf.readline()
            continue
        res.append(line_)
        line =  inf.readline()
    inf.close()
    return res

def get_term_id_dict(data_dir="./data/", file_name="term_id.dict"):    
    file=data_dir + file_name
    try:
        inf = open(file, "r")
    except: 
        print "cant not find term id dict"
        return   
    term_dict = {}
    line  = inf.readline()   
    while line:  
        line = line.strip()  
        if not line:
            break
        line_ = line.split("\t")
        if (len(line_) < 2): 
            line = inf.readline()
            continue
        term_dict[line_[0]] = line_[1]
        line =  inf.readline()
    inf.close()
    return term_dict

def to_ids(terms, dict_tmp):
    if (len(dict_tmp) < 1): 
        return ""  
    res = []  
    for t in terms:
        t =  t.encode("utf8")
        if (not dict_tmp.has_key(t)):
            continue
        res.append(int (dict_tmp[t]))
    return res

def to_string(vec):
    res = ""
    for v in vec:
        res = res + str("%.5f"%v) + " " 
    res = res.strip()
    return res

def output_res(vec_list , title_list):
    if (vec_list.shape[0] != len(title_list)):
        print "ERROR, length of title_list not equal length of vec_list"
        return
    for i in range(len(title_list)):
        title = title_list[i].strip()
        vec   = to_string(vec_list[i])
        if (not title or not vec):
            continue
        print title + "\t" + vec 
    return

