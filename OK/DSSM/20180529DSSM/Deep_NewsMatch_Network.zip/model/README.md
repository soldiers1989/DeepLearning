### 模型训练模块
- run.py： **训练主程序**
- utils.py：辅助程序
- data_shuffle.py：辅助程序
- train.sample ： 训练数据样例

### 模型框架
模型的主要组成如下图

<img src="http://git.code.oa.com/AI_algorithm/Deep_NewsMatch_Network/raw/158bf2a6be58312fe88faabd5c39c66ad129a4e9/img/model.png" width="45%" height="45%">

#### 各步骤说明：
1. **预处理**
    1） 准备训练数据， 表示成<news, pos, neg> 三元组形式； 其中: news为新闻，pos为正例，neg为负例；均采用title 和 正文tag 作为最初的文本表示；
    2） 正例 选取与新闻相关的新闻， 负例随机选取； 正负比例1:1
2. **Input 层**
    将文本数据切词，用切词后term的id， 将文本表示，转成one hot的 id表示， term个数称为 Vocalbulary_size；
3. **embedding层**
    1） 随机初始化一个Vocalbulary_size * N 的embedding表； 
    2） 由于文章的tag个数不固定， 因此 tag_id list 采用sparse的方式表示，title的term_id list采用定长表示；
    3） 对应tf里面，查表方式分别为lookup_sparse_embedding和lookup_embedding；
4. **CNN & BOW层**
    1） title中的term 是有序的，获取title的各个term的embedding之后，采用CNN 过滤， 池化之后获取title的向量表示； 
    2） 文章tag是无序的， 因此，查出tag term的embedding之后，直接加和平均即可；
    3） 将title 、pos、neg 各自的title的向量和tag的向量merger， 各自获得一个merger后vec；
5. **全联通层**
    1） 上一步merger后的向量通过两个全联通层（FC）；
    2） FC层的输出分别为News_vec_fc, Pos_vec_fc, Neg_vec_fc；

6. **相似度得分**
    1） 正例和news的相似度得分：similarity_score_pos = cosine(News_vec_fc, Pos_vec_fc);  
    2） 负例和news的相似度得分：similarity_score_Neg = cosine(News_vec_fc, Neg_vec_fc)
7. **Loss 层**
    1） 对比， similarity_score_pos 和 similarity_score_neg的大小
    2） 计算 loss = tf.maximum(0.,  similarity_score_neg - similarity_score_pos  + margin)；
8. **迭代训练**
    采用SGD，最小化loss；
9. **保存模型**
    训练完成之后，保持各层参数；其中，pos，neg，news共享 embedding、CNN、FC层的参数；
10. **训练过程体验地址** 
    1） http://tesla.oa.com/teslaml/admin/platform.htm?projectId=10011&flowId=13648#
    2） 该训练， 采用新闻CF共现的新闻作为正例，随机新闻为负例， 正负比例1:1， 数据量约 200w 条ins；

### 使用方法
1. 准备好训练数据；
2. run.py 中，根据需要设定修改相应的参数，比如特征维数、训练数据地址、训练次数等；
3. 根据训练数据的样本量，调整模型参数，调参可重点注意两点:
	1）模型各层权重的初始化，bias的初始化；
	2）learning rate， 各级初始化的权重做相应设置
4. 模型训练完成，采用**predict模块**，对需要计算语义向量的文本计算其向量；
5. 使用**search模块**， 完成相似检索等需求；

### 训练数据格式说明
0. 数据说明暂用新闻数据举例；
1. 每行3列， 用";" 间隔，  每列两部分，用"," 间隔； 
2. 数据均是id化之后的训练数据； 第1列是id化后的新闻数据， 第2列是与改新闻相关的正样例， 第3列是与新闻无关的负样例*（正负样例也是新闻）*
3. 每列均有两部分组成，第一部分是新闻title的term id序列， 第二部分为新闻正文提取的tag id序列；

4. 训练数据举例

> 529052 5322 88 20742 2480 201 21864 2233,1603 1477 2233;27056 83251 560 4040 15 2752 1477 114 31439 114 29980 1 4168 1527,1477 4040 128666;515 330 41 2524 134 1635,365 3690 11438

### 数据预处理
1.  训练数据的预处理，过程都是大同小异，主要还是根据自己的需求场景、 设计采用的模型算子，来准备自己的训练数据；
2.  主要步骤一般包括： 
	1）分词， 获取term id词典
	2）将term转成id， 完成id化
	3）校验
	4）整个过程相对比较简单， 暂不提供相应的脚本

### 训练数据的获取
训练数据根据不同的任务需要来获取， 正例可用相关、相似、或者你需要模型达到的目标的数据来获取，负例可用不相关数据如随机数据来充当； 正负比例可根据正负比例的实际分布来调整；
