#!/usr/bin/env python
# vim: set fileencoding=utf-8 :
# @author: bingfeng@tencent.com 
# @date: 2017/06/01 

import numpy

class DataShuffler(object):
    def __init__(self, data, perc_train=0.8):

        total_samples = len(data)
        indexes = numpy.array(range(total_samples))
        numpy.random.shuffle(indexes)
        data = numpy.array(data)
        # Spliting train and test 
        train_samples = int(round(total_samples * perc_train))
        test_samples = total_samples - train_samples

        data = numpy.reshape(data, (total_samples, 3, 1))
        self.train_data = data[indexes[0:train_samples], :]
        self.test_data = data[indexes[train_samples:train_samples + test_samples], :]

    def get_triplet(self, n_triplets=10, is_target_set_train=True,  max_line_size = 128):
        if is_target_set_train:
            target_data = self.train_data
        else:
            target_data = self.test_data
        ## title data
        news_val = []
        news_pos_val = []
        news_neg_val = []
        ## sparse data         
        t_ids = []
        t_val = []
        p_ids = []
        p_val = []
        n_ids = []
        n_val = []
        def get_one_id_val(i, line):
            title_val = []
            tag_idx = []
            tag_val = []
            tag_list = []
            y = 0
            data = line.split(',')
            title_list = data[0].split(' ')
            if len(data)==2:
                tag_list = data[1].split(' ')
            for t in title_list:
                t = t.strip()
                if not t.isdigit():
                    continue    
                y = y + 1
                title_val.append(int(t)+1)
                if (y >= max_line_size - 1):
                    break

            k = 25-len(title_val)
            if(k>0):
                title_val+=[0]*k
            else:
                title_val=title_val[0:25]
        
            y = 0
            for w in tag_list:
                w = w.strip()
                if not w.isdigit():
                    continue
                ids_tmp = []
                ids_tmp.append(i)
                ids_tmp.append(y)
                y = y + 1
                tag_idx.append(ids_tmp)
                tag_val.append(int(w))
                if (y >=max_line_size-1):
                    break     
            return title_val,tag_idx,tag_val

        random_index = numpy.random.choice(target_data.shape[0], n_triplets, replace=False)
        for i in range(n_triplets):
            data_title = target_data[random_index[i], 0][0]
            data_pos   = target_data[random_index[i], 1][0]
            data_neg   = target_data[random_index[i], 2][0]

            title_one_val,tag_one_idx,tag_one_val = get_one_id_val(i, data_title)
            if (title_one_val and tag_one_idx and tag_one_val):
                news_val = news_val + title_one_val
                t_ids = t_ids + tag_one_idx
                t_val = t_val + tag_one_val
            title_one_val,tag_one_idx,tag_one_val = get_one_id_val(i, data_pos)
            if (title_one_val and tag_one_idx and tag_one_val):
                news_pos_val = news_pos_val + title_one_val
                p_ids = p_ids + tag_one_idx
                p_val = p_val + tag_one_val
            title_one_val,tag_one_idx,tag_one_val = get_one_id_val(i, data_neg)            
            if (title_one_val and tag_one_idx and tag_one_val):
                news_neg_val = news_neg_val + title_one_val
                n_ids = n_ids + tag_one_idx
                n_val = n_val + tag_one_val

        title_array = numpy.array(news_val)
        title_id = title_array.reshape((n_triplets, 25))
        title_pos_array = numpy.array(news_pos_val)
        pos_title_id = title_pos_array.reshape((n_triplets, 25))
        title_neg_array = numpy.array(news_neg_val)
        neg_title_id = title_neg_array.reshape((n_triplets, 25))

        return title_id, t_ids, t_val, pos_title_id, p_ids, p_val, neg_title_id, n_ids, n_val


