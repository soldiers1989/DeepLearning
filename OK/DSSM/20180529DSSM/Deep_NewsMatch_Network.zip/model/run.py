#!/usr/bin/env python
# vim: set fileencoding=utf-8 :
# @author: bingfengli@tencent.com
# @date: 2017/06/01

import utils
import os
import sys
import math
from data_shuffle import DataShuffler
import tensorflow as tf
import numpy as np

vocabulary_size = 610753
emb_size = 150
batch_size  = 128
input_max_size = 10
margin = 0.2

kernel_sizes = [3, 4, 5]
n_filters = 50
sentence_len = 25

def main():

    data= utils.load_data(data_dir="./", file_name="data.fortrain")
    data_shuffler = DataShuffler(data)
    
    ## define sparse tensor shape
    sparse_shape    = np.array([batch_size, input_max_size], dtype=np.int32)
    
    ## define embeddings
    embeddings = utils.add_embedding(vocabulary_size, emb_size,   emb_name="embeddings") 
    embedding_zero = tf.constant(0.0, shape=[1, emb_size], dtype=tf.float32)
    embedding_with_zero = tf.concat([embedding_zero, embeddings],0)

    ## define placeholder to reveive input
    input_title_ids     = tf.placeholder(shape=[batch_size, sentence_len], dtype='int32')
    input_pos_ids       = tf.placeholder(shape=[batch_size, sentence_len], dtype='int32')
    input_neg_ids       = tf.placeholder(shape=[batch_size, sentence_len], dtype='int32')        
    ##input sparse ids
    input_tag_ids       = tf.sparse_placeholder(tf.int32)
    input_pos_tag_ids   = tf.sparse_placeholder(tf.int32)
    input_neg_tag_ids   = tf.sparse_placeholder(tf.int32)

    ##----------------------------embedding layer
    title_embedding     = tf.nn.embedding_lookup(embedding_with_zero, input_title_ids)
    title_pos_embedding = tf.nn.embedding_lookup(embedding_with_zero, input_pos_ids)
    title_neg_embedding = tf.nn.embedding_lookup(embedding_with_zero, input_neg_ids)
    
    ## tag embeding 
    tag_embedding       = tf.nn.embedding_lookup_sparse(embeddings, input_tag_ids, None, combiner='mean')
    tag_pos_embedding   = tf.nn.embedding_lookup_sparse(embeddings, input_pos_tag_ids, None,   combiner='mean')
    tag_neg_embedding   = tf.nn.embedding_lookup_sparse(embeddings, input_neg_tag_ids, None,   combiner='mean')

    ##----------------------------CNN layer
    title_3d       = tf.expand_dims(title_embedding, -1)
    title_pos_3d   = tf.expand_dims(title_pos_embedding, -1)
    title_neg_3d   = tf.expand_dims(title_neg_embedding, -1)

    ##Init CNN Filters
    cnn_w0 = tf.Variable(tf.random_uniform([kernel_sizes[0], emb_size, 1, n_filters], -0.2,0.2), dtype='float32', name="cnn_w0")
    cnn_w1 = tf.Variable(tf.random_uniform([kernel_sizes[1], emb_size, 1, n_filters], -0.2,0.2), dtype='float32', name="cnn_w1")
    cnn_w2 = tf.Variable(tf.random_uniform([kernel_sizes[2], emb_size, 1, n_filters], -0.2,0.2), dtype='float32', name="cnn_w2")
    
    cnn_b0 = tf.Variable(tf.constant(0.00001, shape=[n_filters]), name = "cnn_b0")
    cnn_b1 = tf.Variable(tf.constant(0.00001, shape=[n_filters]), name = "cnn_b1")
    cnn_b2 = tf.Variable(tf.constant(0.00001, shape=[n_filters]), name = "cnn_b2")

    #impl cnn
    title_cnn   = utils.get_cnn_feature(cnn_w0, cnn_w1, cnn_w2, cnn_b0, cnn_b1, cnn_b2, title_3d, sentence_len)
    pos_cnn     = utils.get_cnn_feature(cnn_w0, cnn_w1, cnn_w2, cnn_b0, cnn_b1, cnn_b2, title_pos_3d, sentence_len)
    neg_cnn     = utils.get_cnn_feature(cnn_w0, cnn_w1, cnn_w2, cnn_b0, cnn_b1, cnn_b2, title_neg_3d, sentence_len)
    
    ## merger tensor
    title_cnn_bow_merger   = title_cnn + tag_embedding * 0.4
    pos_cnn_bow_merger     = pos_cnn   + tag_pos_embedding * 0.4
    neg_cnn_bow_merger     = neg_cnn   + tag_neg_embedding * 0.4


    ## ----------------------------------fc layer 
    fc_w0, fc_b0 = utils.create_w_b(emb_size, emb_size, w_name="fc_w0", b_name="fc_b0")
    fc_w1, fc_b1 = utils.create_w_b(emb_size, emb_size, w_name="fc_w1", b_name="fc_b1")

    keep_prob = tf.placeholder("float")
    title_z0 = utils.calculate_y(title_cnn_bow_merger, fc_w0, fc_b0, keep_prob)
    title_z1 = utils.calculate_y(title_z0, fc_w1, fc_b1, keep_prob)
    
    pos_z0 = utils.calculate_y(pos_cnn_bow_merger, fc_w0, fc_b0, keep_prob)
    pos_z1 = utils.calculate_y(pos_z0, fc_w1, fc_b1, keep_prob)

    neg_z0 = utils.calculate_y(neg_cnn_bow_merger, fc_w0, fc_b0, keep_prob)
    neg_z1 = utils.calculate_y(neg_z0, fc_w1, fc_b1, keep_prob)
    
    title_z1_n  = tf.nn.l2_normalize(title_z1, 1)
    pos_z1_n    = tf.nn.l2_normalize(pos_z1  , 1)
    neg_z1_n    = tf.nn.l2_normalize(neg_z1  , 1)

    ## ----------------------------------loss layer 
    ## cal losss    
    loss = utils.compute_triplet_loss(title_z1_n, pos_z1_n, neg_z1_n, margin)
    
    batch =  tf.Variable(0)
    learning_rate_emb   = tf.train.exponential_decay(0.0005, batch * batch_size, data_shuffler.train_data.shape[0], 0.9)
    learning_rate_cnn   = tf.train.exponential_decay(0.005, batch * batch_size, data_shuffler.train_data.shape[0], 0.9)
    learning_rate_fc    = tf.train.exponential_decay(0.002, batch * batch_size, data_shuffler.train_data.shape[0], 0.9)
    ##
    var_cnn = [cnn_w0, cnn_w1, cnn_w2, cnn_b0, cnn_b1, cnn_b2]
    var_fc = [fc_w1, fc_b1, fc_w0, fc_b0]
    optimizer_emb = tf.train.GradientDescentOptimizer(learning_rate_emb).minimize(loss, var_list = embeddings)
    optimizer_cnn = tf.train.GradientDescentOptimizer(learning_rate_cnn).minimize(loss, var_list = var_cnn)
    optimizer_fc  = tf.train.GradientDescentOptimizer(learning_rate_fc).minimize(loss, var_list = var_fc)
    optimizer = tf.group(optimizer_emb, optimizer_cnn, optimizer_fc)
    
    with tf.Session() as session:    
        tf.global_variables_initializer().run()
        saver = tf.train.Saver()
        for step in range(400000):
            ## get train data
            title_ids, tag_ids    , tag_val,\
            pos_ids  , tag_pos_ids, tag_pos_val, \
            neg_ids  , tag_neg_ids, tag_neg_val = data_shuffler.get_triplet(n_triplets=batch_size)
            
            ## feed data to tf session
            feed_dict = {  
                input_title_ids:title_ids,
                input_pos_ids  :pos_ids,
                input_neg_ids  :neg_ids,
                input_tag_ids:    (tag_ids, tag_val, sparse_shape),
                input_pos_tag_ids:(tag_pos_ids, tag_pos_val, sparse_shape),
                input_neg_tag_ids:(tag_neg_ids, tag_neg_val, sparse_shape),
                batch: step, keep_prob: 0.8
            }

            ## run optimizer 
            _, l= session.run([optimizer, loss], feed_dict=feed_dict)
            
            ## test model
            if (step % 50 == 0) : 
                ## get test data 
                title_ids,tag_ids,tag_val, \
                pos_ids,tag_pos_ids,tag_pos_val, \
                neg_ids,tag_neg_ids,tag_neg_val \
                    = data_shuffler.get_triplet(n_triplets=batch_size, is_target_set_train=False)
                
                ## feed session 
                f_dict = { 
                           input_title_ids:title_ids,
                           input_pos_ids:pos_ids,
                           input_neg_ids:neg_ids,
                           input_tag_ids:(tag_ids, tag_val, sparse_shape),
                           input_pos_tag_ids:(tag_pos_ids, tag_pos_val, sparse_shape),
                           input_neg_tag_ids:(tag_neg_ids, tag_neg_val, sparse_shape),
                           batch: step, keep_prob: 1.0
                }
                
                ## get acc 
                lv, news_z1_out, pos_z1_out, neg_z1_out = \
                        session.run([loss, title_z1_n, pos_z1_n, neg_z1_n], feed_dict=f_dict)
                                
                acc = utils.get_acc(news_z1_out, pos_z1_out, neg_z1_out, margin)
                print("test loss\t{0}".format(lv))
                print("test acc \t{0}".format(acc))
                print("step     \t{0}".format(step))
                print("-----------------------------------------")

            ## save model
            if (step % 10000 == 0):
                model_dir = "../model/"
                model_name = "dnn-model-" + str(step / 10000) 
                if not os.path.exists(model_dir):
                    os.mkdir(model_dir)
                saver.save(session, os.path.join(model_dir, model_name))

if __name__ == "__main__":
    main()

