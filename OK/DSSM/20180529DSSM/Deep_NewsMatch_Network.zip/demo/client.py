#!/usr/bin/env python
# vim: set fileencoding=utf-8 :
# @author: bingfengli@tencent.com
# @date: 2017/06/01

import socket
import sys

HOST = '100.66.17.132'
PORT = 8084
def main():
    global HOST
    global PORT
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect((HOST,PORT)) 
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        s.sendall(line) 
        data=s.recv(10240) 
        print data
    s.close()


if __name__ == "__main__":
    main()

